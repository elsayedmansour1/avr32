/*
 * main.c
 *
 *  Created on: Aug 23, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"DIO_Interface.h"
#include"I2C_Interface.h"



int main(void)
{
	/* Start Condition */
	I2C_enuSendStartCondition();

	/* Send Slave Address with W operation */
	I2C_enuSendSlaveAddWithWrite( 0x50 );

	/* Send Byte Address */
	I2C_enuMasterSendDataByte(50);

	/* Send Data */
	I2C_enuMasterSendDataByte(50);


//	/* Send Data */
//	I2C_enuMasterSendDataByte(10);

	/* Stop Condition */
	I2C_voidSendStopCondition();
	return 0;
}
