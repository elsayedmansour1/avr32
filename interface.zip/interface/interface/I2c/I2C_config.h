/*
 * I2C_config.h
 *
 *  Created on: Apr 8, 2020
 *      Author: KAPOO
 */

#ifndef I2C_CONFIG_H_
#define I2C_CONFIG_H_



#endif /* I2C_CONFIG_H_ */
