/*
 * main.c
 *
 *  Created on: Aug 9, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include"util/delay.h"
#include"DIO_Interface.h"
#include"Stepper_Interface.h"

void main(void)
{
DIO_VidSetPinDirection(PORTD, PIN0, INPUT);
DIO_VidSetPinDirection(PORTD, PIN1, INPUT);
DIO_VidSetPinValue(PORTD, PIN0, HIGH);
DIO_VidSetPinValue(PORTD, PIN1, HIGH);

while(1)
	{
	if(DIO_vidGitPinValue(PORTD, PIN0)==1)
	{
		SPEED_of_Stepper(1);
		stepper(PORTA, PIN0, PIN1, PIN2, PIN3, Forword);
		REST_Of_Stepper(PORTA, PIN0, PIN1, PIN2, PIN3);
	}
	else if(DIO_vidGitPinValue(PORTD, PIN1)==1)
	{
		SPEED_of_Stepper(1);
		stepper(PORTA, PIN0, PIN1, PIN2, PIN3, Reverise);
		REST_Of_Stepper(PORTA, PIN0, PIN1, PIN2, PIN3);
	}
	}

}

