#ifndef _STEPPER_INTERFACE_H_
#define _STEPPER_INTERFACE_H_

#define Forword  0
#define Reverise 1




void stepper(u8 LOC_Port,u8 INPUT1,u8 INPUT2 ,u8 INPUT3 ,u8 INPUT4,u8 Direction);

void REST_Of_Stepper(u8 LOC_Port,u8 INPUT1,u8 INPUT2 ,u8 INPUT3 ,u8 INPUT4);

void SPEED_of_Stepper(u8 speed);







#endif
