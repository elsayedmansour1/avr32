/*
 * EEPROM_private.h
 *
 *  Created on: Apr 15, 2020
 *      Author: KAPOO
 */

#ifndef EEPROM_PRIVATE_H_
#define EEPROM_PRIVATE_H_

#define EEPROM_FIXED_ADDRESS       0x50

#endif /* EEPROM_PRIVATE_H_ */
