/*
 * EEPROM_config.h
 *
 *  Created on: Apr 15, 2020
 *      Author: KAPOO
 */

#ifndef EEPROM_CONFIG_H_
#define EEPROM_CONFIG_H_

#define EEPROM_A2_VALUE         0

#endif /* EEPROM_CONFIG_H_ */
