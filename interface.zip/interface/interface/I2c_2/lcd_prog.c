/*
 * lcd_prog.c
 *
 *  Created on: Aug 24, 2019
 *      Author: KAPOO
 */

#include "LIB/STD_TYPES.h"
#include "util/delay.h"
#include "DIO_int.h"
#include "lcd_int.h"

void lcd_write_string(u8 * ptr)
{
	u8 index = 0;
	while(ptr[index]!='\0')
	{
		lcd_write_char(ptr[index]);
		index ++;
	}

}

void lcd_init(void)
{
	//directions for control pins => output
	/*1- RS
	 * 2-RW
	 * 3-E
	 * */
	DIO_SetPinDirection(LCD_CONTROL_PORT,LCD_RS,OUTPUT);
	DIO_SetPinDirection(LCD_CONTROL_PORT,LCD_RW,OUTPUT);
	DIO_SetPinDirection(LCD_CONTROL_PORT,LCD_E,OUTPUT);


	//dirctions for data pins
	/*1- set dirction output for lcd data port */

	DIO_SetPortDirection(LCD_DATA_PORT,0xff);






	_delay_ms(40);
	lcd_write_cmnd(FUNCTION_SET_CMND);
	_delay_us(40);
	lcd_write_cmnd(DISPLAY_ON_CURSOR_ON_BLINK_ON);
	_delay_us(40);
	lcd_write_cmnd(DISPLAY_CLEAR);
	_delay_ms(2);
	lcd_write_cmnd(ENTRY_MODE_INCREASE_NO_SHIFTING);

}

void lcd_write_char(u8 data)
{
	//1-choose the cmnd register
	//RS pin = 0
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_RS,HIGH);

	//2-write to the lcd
	//RW pin = 0
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_RW,LOW);

	//3-put the cmnd on the port
	DIO_SetPortValue(LCD_DATA_PORT,data);


	//4-Enable latch
	//set enable to high
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_E,HIGH);
	//delay = 1ms
	_delay_ms(1);
	//set enable to low
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_E,LOW);



}

void lcd_write_cmnd(u8 cmnd)
{
	//1-choose the cmnd register
	//RS pin = 0
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_RS,LOW);

	//2-write to the lcd
	//RW pin = 0
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_RW,LOW);

	//3-put the cmnd on the port
	DIO_SetPortValue(LCD_DATA_PORT,cmnd);


	//4-Enable latch
	//set enable to high
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_E,HIGH);
	//delay = 1ms
	_delay_ms(1);
	//set enable to low
	DIO_SetPinValue(LCD_CONTROL_PORT,LCD_E,LOW);

}

void LCD_WriteNumber(u16 Number)
{
	u8 Counter=0,Digits=0,Current;
	u16 CopyNumber=Number;
	while(CopyNumber)
	{
		CopyNumber/=10;
		Digits++;
	}
	CopyNumber=Number;
	for(Counter=0;Counter<Digits;Counter++)
	{
		Current=CopyNumber/(Private_GetPower(10,Digits-1-Counter));
		lcd_write_char(Current+'0');
		CopyNumber%=(Private_GetPower(10,Digits-1-Counter));
	}
}

u16 Private_GetPower(u8 Num1, u8 Num2)
{

	u16 Result=1;
	u8 Counter=0;
	for(Counter=0;Counter<Num2;Counter++)
	{
		Result*=Num1;
	}
	return Result;
}

void LCD_go_to_xy(u8 x, u8 y)
{
	if(x==1)
	{
		lcd_write_cmnd(0x80+y);

	}
	else
	{
		lcd_write_cmnd(0xc0+y);
	}
}
