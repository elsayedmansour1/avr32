/*
 * lcd_int.h
 *
 *  Created on: Aug 24, 2019
 *      Author: KAPOO
 */

#ifndef LCD_INT_H_
#define LCD_INT_H_

#define LCD_CONTROL_PORT      PORT_D
#define LCD_DATA_PORT         PORT_A

#define LCD_RS                PIN0
#define LCD_RW                PIN1
#define LCD_E                 PIN2


/* Commands Macros */

#define FUNCTION_SET_CMND                0x38
#define DISPLAY_ON_CURSOR_ON_BLINK_ON    0x0f
#define DISPLAY_CLEAR                    0x01
#define ENTRY_MODE_INCREASE_NO_SHIFTING  0x06





/* Prototypes of the functions */

void lcd_init(void);

void lcd_write_char(u8 data);

void lcd_write_cmnd(u8 cmnd);

u16 Private_GetPower(u8 Num1, u8 Num2);

void LCD_WriteNumber(u16 Number);

void LCD_go_to_xy(u8 x, u8 y);
void lcd_write_string(u8 *ptr);





#endif /* LCD_INT_H_ */
