#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include <util/delay.h>

#include "DIO_int.h"
#include "I2C_interface.h"

#include "EEPROM_interface.h"
#include "lcd_int.h"

int main(void)
{
	u8 Local_u8ReturnData;
	/* Port Init */
	/* I2c Init */
	I2C_voidMasterInit();

//	I2C_voidSlaveInit()
	lcd_init();

	EEPROM_u8WriteDataByte(512,200);
	_delay_ms(10);

	EEPROM_u8ReadDataByte(513,&Local_u8ReturnData);

	lcd_write_string("The Value= ");
	LCD_WriteNumber(Local_u8ReturnData);
	_delay_ms(200);
	EEPROM_u8ReadDataByte(513,&Local_u8ReturnData);

	LCD_go_to_xy(1,0);
	lcd_write_string("The Value= ");
	LCD_WriteNumber(Local_u8ReturnData);

	while(1);

	return 0;
}
