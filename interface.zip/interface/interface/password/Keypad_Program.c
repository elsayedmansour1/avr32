#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"
#include"LCD_Interface.h"


void KEYPAD_VidInit(void)
{
	DIO_VidSetPortDirection ( PORTC,0B00001111);
	DIO_VidSetPortValue	( PORTC, 0B11111111);
}
u8 GET_PressedKey(void)
{   u8 keypad_array[4][4]={{1,2,3,4},
		                   {5,6,7,8},
						   {9,10,11,12},
						   {13,14,15,16}};
	u8 col,row;
	u8 keypad_out=0;

	for(col=0;col<4;col++)
	{
		DIO_VidSetPinValue	( PORTC, col, 0);
		for(row=4;row<8;row++)
		{
			if(DIO_vidGitPinValue(PORTC,row)==0)
			{

				keypad_out= keypad_array[row-4][col];
				while(DIO_vidGitPinValue(PORTC,row)==0)
				{
					
				}
				_delay_ms(50);
			}



		}
		DIO_VidSetPinValue	( PORTC, col, 1);
	}

return keypad_out;
}
