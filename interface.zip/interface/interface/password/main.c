/*
 * main.c
 *
 *  Created on: Jun 28, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include "Keypad_Interface.h"
#include "Function.h"
#include"ADC_Interface.h"


void main(void)
{
	LCD_VidInit();
	KEYPAD_VidInit();
	ADC_INIT();

    DIO_VidSetPinDirection(PORTB,PIN3,OUTPUT);
    DIO_VidSetPinDirection(PORTB,PIN4,OUTPUT);
    DIO_VidSetPinDirection(PORTB,PIN5,OUTPUT);
    DIO_VidSetPinValue(PORTB,PIN4,0);
    DIO_VidSetPinValue(PORTB,PIN5,0);
	u8 value;
	u16 value2;
	u16 value3;
	u8 result=0;
	u16 digital_value=0;
	u16 digital_value2=0;
	u16 temp=0;
	u8 counter=0;
	u16 LIGHT=0;
	u16 DARK=0;



	ID();
	LCD_VidWriteCommend(1);
	PASSWORD();
	LCD_VidWriteCommend(1);
	LCD_VidWriteString("Wellcome Elsayed");
	_delay_ms(1000);
	LCD_VidWriteCommend(1);
	SYSTEM_LOADING();
	LCD_VidWriteCommend(1);
	StartScreen();

while(1)
{

	value=GET_PressedKey();

	if(value!=0)
	{
		result=value;
		LCD_VidWriteCommend(1);
		_delay_ms(500);
	}
	else{}
	if(result==1)
	{

		LM_35_SENSOR(ADC0,POLLING,1);
	}
	else if(result==2)
		{

		LDR_SENSOR(ADC1,POLLING,1);
		}
	else if(result==3||result==4)
		{
		GoToXY(0,0);
		LCD_VidWriteString("DC-MOTOR:")	;
		if(result==3)
		{
			GoToXY(0,9);
			LCD_VidWriteString("ON");
			DIO_VidSetPinValue(PORTB,PIN3,1);
		}
		else if(result==4)
		{
			GoToXY(0,9);
			LCD_VidWriteString("OFF");
			DIO_VidSetPinValue(PORTB,PIN3,0);
		}
		else{}
		}
	    else if(result==5)
				{

		     	StartScreen();
		    	DIO_VidSetPinValue(PORTB,PIN3,0);
				}
/*	    else if(result==6)
	    {
	    	LM_35_SENSOR(ADC0,POLLING,2);
	    	_delay_ms(1000);
	    	LDR_SENSOR(ADC1,POLLING,2);
	    	_delay_ms(1000);
	    }*/
}


}
