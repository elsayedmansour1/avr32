#ifndef _Function_H_
#define _Function_H_






void PASSWORD(void);
void ID(void);
void LDR_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus,u8 type);
void LM_35_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus,u8 type);
void StartScreen(void);









#endif
