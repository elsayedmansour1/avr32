#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "Function.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include "Keypad_Interface.h"
#include<avr/delay.h>

u8 value;
u8 value1;
u16 value2;
u16 value3;
u16 digital_value;
u16 digital_value2;
u16 DARK;
u16 LIGHT;
u16 temp;
u16 id=0;
u16 password=0;
u8 not_correct=0;
u8 counter=0;
u16 arr[]={ 0x04,		  0x0A,		  0x04,		  0x00,		  0x00,		  0x00,		  0x00,		  0x00};
void ID(void)
{
	while(1)
	{
	GoToXY(0,0);
		LCD_VidWriteString("ID:");
		value=GET_PressedKey();
		if(value!=0)
		{
			GoToXY(0,counter+3);
			LCD_VidWriteNumber(value);
	     	counter++;
	     	id=id*10+value;
		}
		else{}

		if(id==321&&counter==3)
		{
			GoToXY(1,0);
			LCD_VidWriteString("Correct ID");
			_delay_ms(500);
			id=0;
			counter=0;
			break;
		}
		else if(id!=321&&counter==3)
		{
			GoToXY(1,0);
			LCD_VidWriteString("Incorrect ID");
			_delay_ms(100);
			not_correct++;
			id=0;
			counter=0;
			CLEAR(0,3,7);
			CLEAR(1,0,15);
		}
		else{}
		if(not_correct==3)
		{
		not_correct=0;
		while(1)
		{
			GoToXY(0,0);
			LCD_VidWriteString("    ENTERED ID  ");
			GoToXY(1,0);
			LCD_VidWriteString("  3 TIMES WRONG   ");
		}
		}
	}
	
}

void PASSWORD(void)
{
	while(1)
	{
	GoToXY(0,0);
		LCD_VidWriteString("Password:");
		value1=GET_PressedKey();
		if(value1!=0)
		{
			GoToXY(0,counter+9);
			LCD_VidWriteNumber(value1);
			_delay_ms(200);
			GoToXY(0,counter+9);
			LCD_VidWriteData(42);
			password=password*10+value1;
			counter++;
		}
		if(password==123&&counter==3)
		{
			GoToXY(1,0);
			LCD_VidWriteString("Correct Password");
			_delay_ms(500);
			counter=0;
			break;
		}
		else if(password!=123&&counter==3)
		{
			password=0;
			GoToXY(1,0);
			counter=0;
			LCD_VidWriteString("Incorrect Password");
			_delay_ms(100);
			CLEAR(0,9,15);
			CLEAR(1,0,16);
			not_correct++;
		}
		if(not_correct==3)
		{
			while(1)
			{
				GoToXY(0,0);
				LCD_VidWriteString("   ENTERED PASS  ");
				GoToXY(1,0);
				LCD_VidWriteString("  3 TIMES WRONG   ");
				_delay_ms(2000);
			}
		}	
	}
	

}
void StartScreen(void)
{
	                GoToXY(0,0);
					LCD_VidWriteString("1-LM-35");
					GoToXY(0,10);
					LCD_VidWriteString("2-LDR");
					GoToXY(1,0);
					LCD_VidWriteString("3-DC_MOTOR");
}
void LM_35_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus,u8 type)
{
	value2=ADC_GET_RESULT(LOC_u8SelectChannel,LOC_u8SelectStatus);
    digital_value=(value2*5000UL)/1024;
    temp=digital_value/10;
	if(type==1)
	{
		GoToXY(0,0);
		LCD_VidWriteString("LM-35")	;

		GoToXY(0,8);
		LCD_VidWriteString("BUZZER:")	;



		GoToXY(1,0);
		LCD_VidWriteString("TEMP=");
		LCD_VidWriteNumber(temp);
		LCD_VidWriteString("c");
		if(temp>40)
		{
			DIO_VidSetPinValue(PORTB,PIN4,1);
			GoToXY(1,10);
			LCD_VidWriteString("ON")	;
		}
		else
		{
			DIO_VidSetPinValue(PORTB,PIN4,0);
			GoToXY(1,10);
			LCD_VidWriteString("OFF")	;
		}
		_delay_ms(500);
		CLEAR(1,10,15);
	}
	else if(type==2)
	{

		GoToXY(0,0);
		LCD_VidWriteString("T=");
		LCD_VidWriteNumber(temp);
		GoToXY(0,4);
constant(arr,8,0,4,1);
		LCD_VidWriteData('C');
	}

}
void LDR_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus,u8 type)
{
	if(type==1)
	{
		value3=ADC_GET_RESULT(LOC_u8SelectChannel,LOC_u8SelectStatus);
		digital_value2=(value3*5)/1024;
		DARK=(digital_value2*100)/4;
		LIGHT=100-DARK;
		GoToXY(0,0);
				LCD_VidWriteString("LDR")	;
				GoToXY(0,7);
				LCD_VidWriteString("LED:")	;

				GoToXY(1,0);
				LCD_VidWriteString("LIGHT=");
				LCD_VidWriteNumber(LIGHT);
				GoToXY(1,9);
				LCD_VidWriteData('%');
				if(LIGHT<25)
				{
					DIO_VidSetPinValue(PORTB,PIN5,1);
					GoToXY(0,11);
					LCD_VidWriteString("ON")	;

				}
				else
				{
					DIO_VidSetPinValue(PORTB,PIN5,0);
					GoToXY(0,11);
					LCD_VidWriteString("OFF")	;

				}
				_delay_ms(500);
				CLEAR(0,11,15);
				CLEAR(1,6,9);
	}
	else if(type==2)
	{
		GoToXY(0,7);
		LCD_VidWriteString("B=");
		LCD_VidWriteNumber(LIGHT);
		//LCD_VidWriteData('%');
	}

}
void SYSTEM_LOADING(void)
{
	GoToXY(0,0);
	LCD_VidWriteString("SYSTEM_LOADING");
	GoToXY(1,0);
	for(u8 x=0;x<15;x++)
	{
		LCD_VidWriteData('>');
		_delay_ms(100);
	}

}
