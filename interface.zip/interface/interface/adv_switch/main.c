/*
 * main.c
 *
 *  Created on: Jun 3, 2020
 *      Author: elsay
 */

#include"BIT_MATH.H"
#include"STD_TYPES.H"
#include"DIO_Interface.h"
#include"7SEG_Interface.h"
#include<avr/delay.h>
void main(void)
{u8 Value;
	DIO_VidSetPortDirection	( PORTC, 0X00);     //SET PORTC AS INPUT
	DIO_VidSetPortValue	( PORTC, 0XFF);
	DIO_VidSetPortDirection	( PORTD,0XFF) ;    //SET PORTD AS OUTPUT
	DIO_VidSetPortValue	( PORTD, 0X00);           //TURN OF ALL LEDS

	while(1)
	{    DIO_vidGitPinValue  (PORTC,PIN0);
		if(DIO_vidGitPinValue  (PORTC,PIN0)==1)   //فرح العمده
			{

			    for(u8 i=0;i<8;i++)
			{
				DIO_VidSetPinValue( PORTD,i,1);
				_delay_ms(200);
				DIO_VidSetPinValue( PORTD,i,0);
			}


			//SEG_VidCount(PORTA,CATHOD,UP);
			}
		else if(DIO_vidGitPinValue  (PORTC,PIN1)==1)   //7 segment counter up
		{
			SEG_VidCount(PORTA,CATHOD,UP);
		}
		else if(DIO_vidGitPinValue  (PORTC,PIN2)==1)   //7 segment counter down
				{
					SEG_VidCount(PORTA,CATHOD,DOWN);
				}
		else if(DIO_vidGitPinValue  (PORTC,PIN3)==1)   //7 segment loading
						{
			SEG_VidLoading(PORTA,PORTB);
						}
			else
			{
				//DIO_VidSetPinValue( PORTD,PIN0,0);
				 DIO_VidSetPortValue	( PORTA, 0XFF);
		 DIO_VidSetPortValue	( PORTB,0XFF);
		 DIO_VidSetPortValue	( PORTD, 0X00);

			}
	}

}
