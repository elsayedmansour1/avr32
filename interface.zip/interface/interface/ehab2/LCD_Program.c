#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"avr/delay.h"
#include"DIO_Interface.h"

void LCD_VidIntilaization(void)
{
	_delay_ms(50);
	DIO_VidSetPortDirection(PORTD,0xFF);
	DIO_VidSetPortDirection(PORTA,0b00000111);

	LCD_VidWriteCommand(0b00111000);  //function set
	_delay_ms(1); 
	LCD_VidWriteCommand(0b00001100);  //Diplay_On
	_delay_ms(1); 
	LCD_VidWriteCommand(0b00000001);  //Display_clear
	_delay_ms(2);
}

void LCD_VidWriteCommand(u8 LOC_u8Command)
{
	DIO_VidSetPinValue(PORTA,PIN0,LOW); //RS=0
	DIO_VidSetPinValue(PORTA,PIN1,LOW); //Rw=0
	DIO_VidSetPortValue(PORTD,LOC_u8Command); //Write command or data
	DIO_VidSetPinValue(PORTA,PIN2,HIGH);  //EN=1--rising edge
	_delay_ms(1);
	DIO_VidSetPinValue(PORTA,PIN2,LOW);  //EN=0--falling edge
	_delay_ms(1);

}
void LCD_VidWriteData(u8 LOC_u8Data)
{
	DIO_VidSetPinValue(PORTA,PIN0,HIGH); //RS=1
	DIO_VidSetPinValue(PORTA,PIN1,LOW); //Rw=0
	DIO_VidSetPortValue(PORTD,LOC_u8Data); //Write command or data
	DIO_VidSetPinValue(PORTA,PIN2,HIGH); //EN=1--rising edge
	_delay_ms(1);
	DIO_VidSetPinValue(PORTA,PIN2,LOW); //EN=0--falling edge
	_delay_ms(1);
}

void LCD_VidWriteString(u8 *ptr)
{
	u8 i;
	for(i = 0; ptr[i] != '\0'; i++)
	{
		LCD_VidWriteData(ptr[i]);
	}
}
void LCD_VidMoveWord(u8 *ptr)
{

	 LCD_VidWriteString(ptr);
	_delay_ms(400);
	for(u8 j=40;j>0;j--)
	{
		LCD_VidWriteCommand(0b00000001);  //Display_clear
		for(u8 i=40;i>=j;i--)
		{
			LCD_VidWriteCommand(0b00011100);//Shift Display
		}
		 LCD_VidWriteString(ptr);
		_delay_ms(400);
	}
}

	void LCD_VidWriteNum(u32 LOC_u32num)
	{
		u32 revrese=0;
		u8 y;
		u8 counter=0;
		while(LOC_u32num>0)
		{
			revrese=(revrese*10)+(LOC_u32num)%10;
			if(revrese==0)
			{
				 y=0;
				 counter++;
			}
			LOC_u32num=LOC_u32num/10;
		}
		while(revrese>0)
		{
			u8 res=revrese%10;
			LCD_VidWriteData(res+48);
			revrese=revrese/10;
		}
		if(y==0)
		{
			for(u8 i=0;i<counter;i++)
			{
		LCD_VidWriteData(48);
			}
		}
	}

	void LCD_VidSetPosition(u8 LOC_u8Row,u8 LOC_u8Column)
	{
		if(LOC_u8Row==0)
		{
			LCD_VidWriteCommand(128+LOC_u8Column);

		}
		else if(LOC_u8Row==1)
				{
					LCD_VidWriteCommand(128+64+LOC_u8Column);
				}
	}

