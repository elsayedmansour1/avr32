#ifndef _LCD_INTERFACE_H_
#define _LCD_INTERFACE_H_

#define D0 0
#define D0 0
#define D0 0
#define D0 0
#define D0 0
#define D0 0

#define D0 0
#define D0 0
#define D0 0

void LCD_VidIntilaization(void);

void LCD_VidWriteCommand(u8 LOC_u8Command);

void LCD_VidWriteData(u8 LOC_u8Data);

void LCD_VidWriteString(u8 *ptr);

void LCD_VidMoveWord(u8 *LOC_u8ptr);

void LCD_VidWriteNum(u32 LOC_u32num);

void LCD_VidSetPosition(u8 LOC_u8Row,u8 LOC_u8Column);







#endif