#ifndef _KEYBAD_INTERFACE_H_
#define _KEYBAD_INTERFACE_H_


void KEYBAD_VidInit(void);
u8 KEYBAD_VidGetPressed(void);






#endif
