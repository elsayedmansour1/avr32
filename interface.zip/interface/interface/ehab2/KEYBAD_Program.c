#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"avr/delay.h"
#include"DIO_Interface.h"  


void KEYBAD_VidInit(void)
{
	DIO_VidSetPortDirection(PORTA,0b00001111);
	DIO_VidSetPortValue(PORTA,255);

} 


u8 KEYBAD_VidGetPressed(void)
{
	u8 Keybad_out=0;
	u8 col;
	u8 row;
	u8 keybad_array[4][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
	for(col=0;col<4;col++)
	{
		DIO_VidSetPinValue(PORTA,col,0);
		for(row=4 ; row< 8 ; row++ )
		{

			if(DIO_u8GetPinValue( PORTA , row ) ==0)
			{
				Keybad_out= keybad_array[row-4][col];
				while(DIO_u8GetPinValue(PORTA,row)==0)
				{
				}
				_delay_ms(20);
			}
		}
		DIO_VidSetPinValue(PORTA,col,1);
	}
	return Keybad_out;
}                                                                                                             ;
