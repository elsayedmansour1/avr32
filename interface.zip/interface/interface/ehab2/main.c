/*
 * main.c
 *
 *  Created on: Jun 6, 2020
 *      Author: Ahmed Ehab
 */

#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"LCD_Interface.h"
#include"KEYBAD_Interface.h"
#include"avr/delay.h"
void main(void)
{
	LCD_VidIntilaization();
	 KEYBAD_VidInit();
	while(1)
	{

			u8 value= KEYBAD_VidGetPressed();
			if (value !=0)
			LCD_VidWriteNum(value);
	}
}
