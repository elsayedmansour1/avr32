/*
 * main.c
 *
 *  Created on: Jun 6, 2020
 *      Author: elsay
 */
#include "STD_TYPES.h"
#include "LCD_Interface.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include<avr/delay.h>
#include "Keypad_Interface.h"


void main(void)
{ u8 keypad_out;
	LCD_VidInit();
	KEYPAD_VidInit();
	//LCD_VidWriteData('+');
	//LCD_VidWriteData(+);
	//LCD_VidWriteNumber(19);
	while(1)
	{   keypad_out=GET_PressedKeyNew();

	if(keypad_out!=0)
	{
		LCD_VidWriteNumber(keypad_out);
	}

	}
}

