#ifndef _KEYPAD_INTERFACE_H_
#define _KEYPAD_INTERFACE_H_





void KEYPAD_VidInit(void);

u8 GET_PressedKey(void);

u8 GET_PressedKeyNew(void);

s8 KEYPAD_VidCal(u8 x,u8 ch);















#endif
