#ifndef _LCD_INTERFACE_H_
#define _LCD_INTERFACE_H_









void LCD_VidInit(void);
/*      */
void LCD_VidWriteCommend(u8 LCD_u8Commend);
/*  */
void LCD_VidWriteData(u8 LCD_u8Data);

void LCD_VidWriteString(u8 *ptr);

void LCD_VidSetMove(u8 *ptr,u8 max);

void LCD_VidWriteNumber(u32 x);

void LCD_GoToXY(u8 row,u8 col);

void LCD_CLEAR(u8 Row,u8 start,u8 end);


void LCD_CONSTANT(u8 *Arr,u8 Adress,u8 Row,u8 Col,u8 Data);















#endif
