/*
 * main.c
 *
 *  Created on: Jul 11, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Configuration.h"
void main(void)
{
	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX
	DIO_VidSetPinDirection(PORTA,PIN0,OUTPUT);

	LCD_VidInit();
	UART_INIT();

	u8 data=0;

while(1)
{

	data=UART_Recive();
	if(data=='w')
	{
		DIO_VidSetPinValue(PORTA, PIN0, 1);
		UART_Transmit('o');
		UART_Transmit('n');
		UART_Transmit('/');
		LCD_
	}
	else if(data=='s')
	{
		DIO_VidSetPinValue(PORTA, PIN0, 0);
		UART_Transmit('o');
		UART_Transmit('f');
		UART_Transmit('f');
		UART_Transmit('/');
	}
}
}
