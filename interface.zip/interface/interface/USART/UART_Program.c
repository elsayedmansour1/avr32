#include "STD_TYPES.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"UART_Interface.h"



u8 Temporary_REG=0;
void UART_INIT(void)
{
     /*enable*/
	Receiver_Enable;
	Transmitter_Enable;
	/*Character Size*/
	//Eight_Bit;
	/*Register Select*/
	//SET_BIT( Temporary_REG , URSEL );

	USCRC=0b10000110;
	
	UBRRH=0;
	UBRRL=51;



}
void UART_Transmit (u16 SEND)
{


	while(GET_BIT(USCRA,UDRE)==0)
	{

	}
	UDR=SEND;

}
u8 UART_Recive (void)
{
	u8 result=0;
	while(GET_BIT(USCRA,RXC)==0){}

	result=UDR;
	return result;
}
