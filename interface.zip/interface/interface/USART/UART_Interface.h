#ifndef _UART_INTERFACE_H_
#define _UART_INTERFACE_H_


void UART_INIT(void);
void UART_Transmit (u16 SEND);
u8 UART_Recive (void);



















#endif
