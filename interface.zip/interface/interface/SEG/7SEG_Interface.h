#ifndef _7SEG_INTERFACE_H_
#define _7SEG_INTERFACE_H_


#define cathod 1
#define anode  0  

void SEG_VidCount(u8 LOC_u8Port,u8 LOC_u8Type,u8 LOC_u8countType);
void SEG_VidCountTo99(u8 LOC_u8Port_1,u8 LOC_u8Port_2);
















#endif
