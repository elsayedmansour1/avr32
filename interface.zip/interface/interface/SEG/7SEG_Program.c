#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
//#include"DIO_Interface.h"


void SEG_VidCount(u8 LOC_u8Port,u8 LOC_u8Type,u8 LOC_u8CountType)
{   u8 cath[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};

    u8 ano[10]={~0XC0,~0XF9,~0XA4,~0XB0,~0X99,~0X92,~0X82,~0XF8,~0X80,~0X90};
    if(LOC_u8Type==1)      // type 1 mean cathod
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DDRA=0XFF;       // Set portA as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DDRB=0XFF;      // Set portB as output
	if(LOC_u8CountType==1)     // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)     // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DDRC=0XFF;     // Set portC as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 :
		DDRD=0XFF;     // Set portD as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =cath[i];
		_delay_ms(300);
	}
		
	}
          if(LOC_u8CountType==0)    // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }
     if(LOC_u8Type==0)      // type 1 mean Anode
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DDRA=0XFF;  // Set portA as output
	if(LOC_u8CountType==1)   // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)    // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DDRB=0XFF;       // Set portB as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DDRC=0XFF;       // Set portB as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 : 
		DDRD=0XFF;        // Set portD as output
	if(LOC_u8CountType==1)     // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }

}

void SEG_VidCountTo99(u8 LOC_u8Port_1,u8 LOC_u8Port_2)
{
	u8 cath[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};

if( LOC_u8Port_1==0 & LOC_u8Port_2==1)   //PORTA&& PORTB
{

DDRA=0XFF;
DDRB=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTB=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[i];
		_delay_ms(300);
	}

	}
}
if( LOC_u8Port_1==0 && LOC_u8Port_2==2)  //PORTA && PORTC
{

DDRA=0XFF;
DDRC=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTC=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==0 && LOC_u8Port_2==3)//PORTA && PORTD
{

DDRA=0XFF;
DDRD=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTD=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==1 && LOC_u8Port_2==0)//PORTB && PORTA
{

DDRA=0XFF;
DDRB=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTA=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTB=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==1 && LOC_u8Port_2==2)   //PORTB && PORTC
{

DDRA=0XFF;
DDRC=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTC=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTB =cath[i];
		_delay_ms(300);
	}
	}


}
if(LOC_u8Port_1==1 &&  LOC_u8Port_2==3)  //PORTB && PORTD
{

DDRD=0XFF;
DDRB=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTD=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTB=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==2 && LOC_u8Port_2==0)//PORTC && PORTA
{

DDRA=0XFF;
DDRC=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTA=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTC=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==2 && LOC_u8Port_2==1)//PORTC && PORTB
{

DDRC=0XFF;
DDRB=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTB=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTC=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==2 && LOC_u8Port_2==3)//PORTC && PORTD
{

DDRC=0XFF;
DDRD=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTD=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTC=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==3 &&LOC_u8Port_2==0)//PORTD && PORTA
{

DDRA=0XFF;
DDRD=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTA=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTD =cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==3 &&LOC_u8Port_2==1)//PORTD && PORTB
{

DDRD=0XFF;
DDRB=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTB=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTD=cath[i];
		_delay_ms(300);
	}

	}
}
if(LOC_u8Port_1==3 && LOC_u8Port_2==2)     //PORTD && PORTC
{

DDRD=0XFF;
DDRC=0XFF;
      for(u8 x=0;x<10;x++)
	{
    		PORTC=cath[x];
    		_delay_ms(300);
		for(u8 i=0;i<10;i++)
	{
		PORTD=cath[i];
		_delay_ms(300);
	}

	}
}

}
