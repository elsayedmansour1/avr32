/*
 * main.c

 *
 *  Created on: Jun 19, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include"EXIT_Interface.h"
#include"DIO_Interface.h"
#include"Global_Interrupt_Enable_Interface.h"
#include<avr/delay.h>
void main(void)
{
	DIO_VidSetPinDirection(PORTA,PIN0,OUTPUT);
	DIO_VidSetPinDirection(PORTA,PIN1,OUTPUT);
	DIO_VidSetPinDirection(PORTA,PIN2,OUTPUT);
    EXTINT_VidINT(INT0);
    EXTINT_VidEnable(INT0);
    EXTINT_VidINT(INT1);
    EXTINT_VidEnable(INT1);
    EXTINT_VidINT(INT2);
    EXTINT_VidEnable(INT2);
	SREG_VidEnable();

	while(1)
	{
		DIO_VidSetPinValue(PORTA,PIN0,0);
		DIO_VidSetPinValue(PORTA,PIN1,0);
		DIO_VidSetPinValue(PORTA,PIN2,0);
	}
}
