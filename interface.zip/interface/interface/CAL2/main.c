/*
 * main.c
 *
 *  Created on: Jun 10, 2020
 *      Author: elsay
 */

#include "STD_TYPES.h"
#include "LCD_Interface.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include<avr/delay.h>
#include "Keypad_Interface.h"
void main(void)
{
	u8 keypad_out,sign,equal,shift;
	LCD_VidInit();
	KEYPAD_VidInit();
	u8 res1=0;
	u8 res2=0;
	u8 res3=0;
	u8 res4=0;
	u8 flag=0;
	while(1)
	{
		keypad_out=GET_PressedKeyNew();     //FOR ANY NUMBER
	    sign=KEYPAD_SIGN();                 //FOR OPERATIONS
	    equal=KEYPAD_EQUAL();               //FOR RESULT
		if(keypad_out!=0)                    //IF USER ENTER ANY NUMBER
		{
			LCD_VidWriteNumber(keypad_out);  //TO SHOW THE NUMBER IN LCD
			if(flag==0)
			{
				res1=keypad_out+res1*10;
			}
			else if(flag==1)
			{
				res1=keypad_out+res1;
				//flag=0;
			}




		}
		else if(sign!=0)
		{
			LCD_VidWriteData(sign);
			flag=1;
		}
		else if(equal!=0)
		{
			LCD_VidWriteData(equal);
			LCD_VidWriteNumber(res1);
		}

	}
	/*u8 value1=0;
	u8 value2=0;
	u8 value3=0;
	u8 sum=0;
	u8 sub=0;
	u8 mult=1;
	u8 final1=0;
	u8 final2=0;
	u8 num1=0;
	u8 num2=0;
	u8 flag=0;
	u8 last_num=0;
	u8 el2=0;
	u8 clear=0;*/

	/*while(1)
	{
		LCD_VidWriteCommend(0b00001110);    //TO SHOW THE CURSER
		keypad_out=GET_PressedKeyNew();     //FOR ANY NUMBER
	    sign=KEYPAD_SIGN();                 //FOR OPERATIONS
	    equal=KEYPAD_EQUAL();               //FOR RESULT
	    shift=KEYPAD_SHIFT();               //FOR SHIFT RIGHT OR LEFT
	    clear=KEYPAD_CLEAR();               //FOR CLEAR LCD

	if(keypad_out!=0)                    //IF USER ENTER ANY NUMBER
	{
		LCD_VidWriteNumber(keypad_out);  //TO SHOW THE NUMBER IN LCD
		value1=keypad_out;
		if(flag==0)                    //any number before sign;
		{
			num1=value1;
		}
		else if(flag==1)               //any number after sign;
		{
		    num2=value1;
		}



	}
	else if(sign!=0)
		{
			LCD_VidWriteData(sign);
			value2=sign;
			flag=1;


		}
	else if(equal!=0)
			{
				LCD_VidWriteData(equal);
				value3=equal;
				if(value2==43)
				{
					 sum=final1+final2;      // for summation
			         LCD_VidWriteNumber(sum);
				}
				else if(value2==45)
				{
					 sub=final1-final2;    // for subtraction
		             LCD_VidWriteNumber(sub);
				}
				else if(value2==42)       // for multiply
				{
					 mult=final1*final2;
					 LCD_VidWriteNumber(mult);
				}

			}
	else if(shift!=0)
			{
		        if(shift==2)                     //shift to right
		        {
		        	LCD_VidWriteCommend(0B00010100);
		        }
	            else if(shift==3)               //shift to left
				{
					LCD_VidWriteCommend(0B00010000);
					if(value2==0)
					{
						final1=final1-last_num;
						final1=final1/10;
					}
					else
					{
						final2=final2-last_num;
						final2=final2/10;
					}

				}
			}
	else if(clear!=0)
	{
		 LCD_VidWriteCommend(1);
		 value1=0;
		 value2=0;
		 value3=0;
		 num1=0;
		 num2=0;
		 flag=0;
		 sum=0;
		 sub=0;
		 mult=1;
		 final1=0;
		 final2=0;
		 last_num=0;
		 el2=0;
		 clear=0;

	}
 if(num1!=0)
				{
					final1=final1*10+num1;
					last_num=num1;
					num1=0;
				}

 if(num2!=0)
				{
					final2=final2*10+num2;
					last_num=num2;
					num2=0;
					//flag=0;
				}



	} //the bracket for endless while loop*/


}    //the bracket for main
