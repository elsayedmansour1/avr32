#include "STD_TYPES.h"
#include "LCD_Register.h"
#include "BIT_Math.h"
#include "avr/delay.h"
#include"DIO_Interface.h"




//0B00111000;
//0B00001100;








void LCD_VidInit(void)
{               _delay_ms(50);
  /*set direction*/
	DIO_VidSetPortDirection(PORTD,0XFF);
	DIO_VidSetPortDirection(PORTB,0B00000111);
	
	LCD_VidWriteCommend(0B00111000);//function set
	_delay_ms(1);
	LCD_VidWriteCommend(0B00001100);//screen on
          _delay_ms(1);
	LCD_VidWriteCommend(0B00000001);//clear display
          _delay_ms(2);
	LCD_VidWriteCommend(0B00000110);//Mode Set
	LCD_VidWriteCommend(0B00000010);//Return Home
	LCD_VidWriteCommend(0B00000001);
	LCD_VidWriteCommend(0B00000001);
}
void LCD_VidWriteCommend(u8 LCD_u8Commend)
{
	DIO_VidSetPinValue(PORTB,PIN0,0);  //RS=0
	DIO_VidSetPinValue(PORTB,PIN1,0);  //RW=0
	DIO_VidSetPortValue(PORTD,LCD_u8Commend); //write commend
	
	DIO_VidSetPinValue(PORTB,PIN2,1);  //EN=1
	_delay_ms(1);
	DIO_VidSetPinValue(PORTB,PIN2,0);  //EN=0
	
	_delay_ms(1);     //wait lcd to write letter
	
}
void LCD_VidWriteData(u8 LCD_u8Data)
{
	DIO_VidSetPinValue(PORTB,PIN0,1);  //RS=0
	DIO_VidSetPinValue(PORTB,PIN1,0);  //RW=0
	DIO_VidSetPortValue(PORTD,LCD_u8Data); //write commend
	
	DIO_VidSetPinValue(PORTB,PIN2,1);  //EN=1
	_delay_ms(1);
	DIO_VidSetPinValue(PORTB,PIN2,0);  //EN=0
	
	_delay_ms(1);     //wait lcd to write letter
}
void LCD_VidWriteString(u8 *ptr)
{
	for(u8 i=0;i<100;i++)
	{
		if(ptr[i]=='\0')
		    {
		    	break;
		    }
	LCD_VidWriteData(ptr[i]);

	}
	
}

void LCD_VidSetMove(u8 *ptr,u8 max)
{
	u8 m=1;
	u8 i;
	for(u8 z=0;z<max;z++)
	{
		for(u8 x=0;x<40;x++)
		{
			LCD_VidWriteCommend(0B00000001);//clear display
			for(i=0;i<m;i++)
			{

				LCD_VidWriteCommend(0B00011100);//cursor
			}
			m++;

			LCD_VidWriteString(ptr);
			_delay_ms(400);
		}
	}




}
void LCD_VidWriteNumber(u32 LOC_u32num)
{
	u32 revrese=0;
	u8 y;
	u8 counter=0;
	if(LOC_u32num==0)
	{
		LCD_VidWriteData(48);
	}
	while(LOC_u32num>0)
	{
		revrese=(revrese*10)+(LOC_u32num)%10;
		if(revrese==0)
		{
			 y=0;
			 counter++;
		}
		LOC_u32num=LOC_u32num/10;
	}
	while(revrese>0)
	{
		u8 res=revrese%10;
		LCD_VidWriteData(res+48);
		revrese=revrese/10;
	}
	if(y==0)
	{
		for(u8 i=0;i<counter;i++)
		{
	LCD_VidWriteData(48);
		}
	}
}

/*u32 Summation(u32 LOC_u32num_1,u32 LOC_u32num_2)
{
	u32 result=LOC_u32num_1 + LOC_u32num_2;

	return result;
}*/
