#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"
#include"LCD_Interface.h"


void KEYPAD_VidInit(void)
{
	DIO_VidSetPortDirection ( PORTA,0B00001111);
	DIO_VidSetPortValue	( PORTA, 0B11111111);
}
u8 GET_PressedKey(void)
{   u8 keypad_array[4][4]={{1,2,3,4},
		                   {5,6,7,8},
						   {9,10,11,12},
						   {13,14,15,16}};
	u8 col,row;
	u8 keypad_out=0;
	//s8 i=3;
	for(col=0;col<4;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
		for(row=4;row<8;row++)
		{
			if(DIO_vidGitPinValue(PORTA,row)==0)
			{

				keypad_out= keypad_array[row-4][col];
				while(DIO_vidGitPinValue(PORTA,row)==0)
				{
					
				}
				_delay_ms(50);
			}



		}
		DIO_VidSetPinValue	( PORTA, col, 1);
	}
	//keypad_out=1;
return keypad_out;
}
u8 keypad_array[3][3]={{1 ,2 ,3,},
		               {4 ,5 ,6,},
		               {7 ,8 ,9,}};

s8 y=0;
u8 ch=0;
u8 counter=0;
//s8 y=keypad_out;
u8 GET_PressedKeyNew(void)           //this function for numbers from 1 to 9
{

		u8 col,row;
		u8 keypad_out=0;


			for(col=0;col<3;col++)
				{
				DIO_VidSetPinValue	( PORTA, col, 0);
				for(row=4;row<7;row++)
				{
				if(DIO_vidGitPinValue(PORTA,row)==0)
				{
					keypad_out= keypad_array[row-4][col];
					while(DIO_vidGitPinValue(PORTA,row)==0)
									{

									}
					_delay_ms(50);
				}


				}


				DIO_VidSetPinValue	( PORTA, col, 1);
				}
			return keypad_out;
				}

u8 KEYPAD_SIGN(void)                                               //this function for {+,-,*}
{u8 row;                                                          //"+"--> in col -->3 row -->4
	u8 sign[3]={'+','-','*'} ;                                    //"-"--> in col -->3 row -->5
	u8 value=0;                                                   //"*"--> in col -->3 row -->6
	DIO_VidSetPinValue	( PORTA, 3, 0);
	for(row=4;row<7;row++)
					{
					if(DIO_vidGitPinValue(PORTA,row)==0)
					{
						value= sign[row-4];
						while(DIO_vidGitPinValue(PORTA,row)==0)
										{

										}
						_delay_ms(50);
					}


					}
	DIO_VidSetPinValue	( PORTA, 3, 1);
	   return value;



}

u8 KEYPAD_EQUAL(void)
{

	u8 keypad_out=0;
	u8 equal[]={'='} ;         //"="--> in col -->3 row -->7


			DIO_VidSetPinValue	( PORTA, 3, 0);

			if(DIO_vidGitPinValue(PORTA,7)==0)
			{
				keypad_out= equal[0];
				while(DIO_vidGitPinValue(PORTA,7)==0)
								{

								}
				_delay_ms(50);
			}
			DIO_VidSetPinValue	( PORTA, 3, 1);
			return keypad_out;

			}
u8 KEYPAD_SHIFT(void)      //  i put two shift {shift right and shift left}
{u8 col;                  //"shift right"--> in col -->1 row -->7
	u8 shift_out=0;      //"shift left"--> in col -->2 row -->7
	u8 shift[]={2,3};
	for(col=1;col<3;col++)
	{
		DIO_VidSetPinValue(PORTA,col,0);
			if(DIO_vidGitPinValue(PORTA,7)==0)
						{
				       shift_out=  shift[col-1];
			           while(DIO_vidGitPinValue(PORTA,7)==0)
							{

							}
						_delay_ms(50);
						}
			DIO_VidSetPinValue	( PORTA, col, 1);
	}

	return shift_out;
}
u8 KEYPAD_CLEAR(void)         //this function to clear
{                            //"clear"--> in col -->0 row -->7
	u8 CLEAR=0;
		DIO_VidSetPinValue(PORTA,0,0);
		if(DIO_vidGitPinValue(PORTA,7)==0)
					{
			       CLEAR= 3;
		           while(DIO_vidGitPinValue(PORTA,7)==0)
						{

						}
					_delay_ms(50);
					}
		DIO_VidSetPinValue	( PORTA, 0, 1);
		return CLEAR;
}


