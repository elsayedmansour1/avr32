/*
 * main.c
 *
 *  Created on: Jun 1, 2020
 *      Author: elsay
 */
#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include "7SEG_Interface.h"
#include<avr/delay.h>

void main(void)
{

	//SEG_VidCounter(PORTA,1);

	while(1)
	{
		SEG_VidCount(PORTA ,cathod , up);
			SEG_VidCount(PORTA ,cathod , down);
	}
}
