#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
//#include"DIO_Interface.h"


void SEG_VidCount(u8 LOC_u8Port,u8 LOC_u8Type,u8 LOC_u8CountType)
{   u8 cath[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};
    u8 ano[10]={~0XC0,~0XF9,~0XA4,~0XB0,~0X99,~0X92,~0X82,~0XF8,~0X80,~0X90};
    if(LOC_u8Type==1)
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DDRA=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTA, cath[i]);
		//PORTA =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTA, cath[9-i]);
		//PORTA =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DIO_VidSetPortDirection	( PORTB, 0XFF);
		//DDRB=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTB, cath[i]);
	//	PORTB =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTB, cath[9-i]);
		//PORTB =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DIO_VidSetPortDirection	( PORTC, 0XFF);
		//DDRC=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTC, cath[i]);
	//	PORTC =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTC, cath[9-i]);
		//PORTC =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 :
		DIO_VidSetPortDirection	( PORTC, 0XFF);
		//DDRC=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
			DIO_VidSetPortValue	( PORTD, cath[i]);
	//	PORTD =cath[i];
		_delay_ms(300);
	}
		
	}
if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }
     if(LOC_u8Type==0)
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DIO_VidSetPortDirection	( PORTA, 0XFF);
		//DDRA=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DIO_VidSetPortDirection	( PORTB, 0XFF);
	//	DDRB=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DIO_VidSetPortDirection	( PORTC, 0XFF);
		//DDRC=0XFF;
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 :
		DIO_VidSetPortDirection	( PORTC, 0XFF);
		//DDRC=0XFF;
	if(LOC_u8CountType==1)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }

}
