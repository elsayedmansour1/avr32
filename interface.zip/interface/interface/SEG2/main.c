/*
 * main.c
 *
 *  Created on: Jun 2, 2020
 *      Author: elsay
 */
#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include "7SEG_Interface.h"
#include<avr/delay.h>

void main(void)
{

	while(1)
	{
		//SEG_VidLoading(PORTA,PORTB);
		//SEG_VidCountTo(PORTA,PORTB,15);
		//_delay_ms(500);
		SEG_VidCount(PORTA,CATHOD,UP);
		/*_delay_ms(500);
		SEG_VidCount(PORTA,CATHOD,DOWN);
		_delay_ms(500);*/
}
}
