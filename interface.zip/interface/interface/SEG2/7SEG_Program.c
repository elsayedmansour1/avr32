#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
//#include"DIO_Interface.h"


void SEG_VidCount(u8 LOC_u8Port,u8 LOC_u8Type,u8 LOC_u8CountType)
{   u8 cath[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};

    u8 ano[10]={~0XC0,~0XF9,~0XA4,~0XB0,~0X99,~0X92,~0X82,~0XF8,~0X80,~0X90};
    if(LOC_u8Type==1)      // type 1 mean cathod
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DDRA=0XFF;       // Set portA as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DDRB=0XFF;      // Set portB as output
	if(LOC_u8CountType==1)     // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)     // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DDRC=0XFF;     // Set portC as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =cath[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =cath[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 :
		DDRD=0XFF;     // Set portD as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =cath[i];
		_delay_ms(300);
	}
		
	}
          if(LOC_u8CountType==0)    // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }
     if(LOC_u8Type==0)      // type 1 mean Anode
    {
	    switch(LOC_u8Port)
	{
	case 0 :
		DDRA=0XFF;  // Set portA as output
	if(LOC_u8CountType==1)   // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)    // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTA =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;

	case 1 :
		DDRB=0XFF;       // Set portB as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTB =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 2 :
		DDRC=0XFF;       // Set portB as output
	if(LOC_u8CountType==1)    // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTC =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	case 3 : 
		DDRD=0XFF;        // Set portD as output
	if(LOC_u8CountType==1)     // counter type 1 mean up
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[i];
		_delay_ms(300);
	}
		
	}
	if(LOC_u8CountType==0)   // counter type 0 mean down
	{
		for(u8 i=0;i<10;i++)
	{
		PORTD =ano[9-i];
		_delay_ms(300);
	}
		
	}
	break;
	}
    }

}


void SEG_VidCountTo(u8 LOC_u8Port1,u8 LOC_u8Port2,u8 LOC_u8Number)
{u8 cath[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};
u8 cath1[10]={0X40,0X79,0X24,0X30,0X19,0X12,0X02,0XB8,0X00,0X10};

	u8 mod =LOC_u8Number%10;
	u8 div =LOC_u8Number/10;
	for(u8 i=0;i<=div;i++)
	{ 
        switch (LOC_u8Port1)
        {
	case 0:PORTA=cath[0];break;
	case 1:PORTB=cath[0];break;
	case 2:PORTC=cath[0];break;
	case 3:PORTD=cath[0];break;
        }
          switch (LOC_u8Port2)
          {
	case 0:DDRA=0XFF;PORTA=cath1[i];break;
	case 1:DDRB=0XFF;PORTB=cath1[i];break;
	case 2:DDRC=0XFF;PORTC=cath1[i];break;
	case 3:DDRD=0XFF;PORTD=cath1[i];break;
          }
	_delay_ms(300);
	for(u8 x=0;x<10;x++)
	{
          switch (LOC_u8Port1)
          {
	case 0:DDRA=0XFF;PORTA=cath[x];break;
	case 1:DDRB=0XFF;PORTB=cath[x];break;
	case 2:DDRC=0XFF;PORTC=cath[x];break;
	case 3:DDRD=0XFF;PORTD=cath[x];break;
          }
	_delay_ms(300);
          if(i==div&&x==mod)
	{
		break;
	}
	}	
	}
}
void SEG_VidLoading(u8 LOC_u8Port1,u8 LOC_u8Port2)
{     for(u8 i=0;i<4;i++)
	{
	          switch (LOC_u8Port1)
          {
	case 0:DDRA=0XFF;PORTA=~(0B00000001<<i);break;
	case 1:DDRB=0XFF;PORTB=~(0B00000001<<i);break;
	case 2:DDRC=0XFF;PORTC=~0B00000001<<i;break;
	case 3:DDRD=0XFF;PORTD=~0B00000001<<i;break;
          } 
	          _delay_ms(200);
	}
switch (LOC_u8Port1)
{
case 0:PORTA=~(0B00000000);break;
case 1:PORTB=~(0B00000000);break;
case 2:PORTC=~(0B00000000);break;
case 3:PORTD=~(0B00000000);break;
}
	 for(u8 i=0;i<3;i++)
	{
	          switch (LOC_u8Port2)
          {
	case 0:DDRA=0XFF;PORTA=~(0B00001000<<i);break;
	case 1:DDRB=0XFF;PORTB=~(0B00001000<<i);break;
	case 2:DDRC=0XFF;PORTC=~0B00001000<<i;break;
	case 3:DDRD=0XFF;PORTD=~0B00001000<<i;break;
          }
	_delay_ms(200);
	}
	 switch (LOC_u8Port2)
	 {
	 case 0:PORTA=~(0B00000001);break;
	 case 1:PORTB=~(0B00000001);break;
	 case 2:PORTC=~(0B00000001);break;
	 case 3:PORTD=~(0B00000001);break;
	 }
	 _delay_ms(200);
	 switch (LOC_u8Port2)
	 {
	 case 0:PORTA=~(0B00000000);break;
	 case 1:PORTB=~(0B00000000);break;
	 case 2:PORTC=~(0B00000000);break;
	 case 3:PORTD=~(0B00000000);break;
	 }

}
