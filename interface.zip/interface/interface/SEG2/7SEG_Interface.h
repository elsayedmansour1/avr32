#ifndef _7SEG_INTERFACE_H_
#define _7SEG_INTERFACE_H_


#define CATHOD 1
#define ANODE  0

#define UP 1
#define DOWN 0

void SEG_VidCount(u8 LOC_u8Port,u8 LOC_u8Type,u8 LOC_u8countType);
void SEG_VidCountTo(u8 LOC_u8Port1,u8 LOC_u8Port2,u8 LOC_u8Number);
void SEG_VidLoading(u8 LOC_u8Port1,u8 LOC_u8Port2);















#endif
