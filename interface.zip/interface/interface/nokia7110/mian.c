/*
 * mian.c
 *
 *  Created on: Aug 21, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
void main(void)
{
	DIO_VidSetPinDirection(PORTB, PIN0, OUTPUT);
	DIO_VidSetPinDirection(PORTB, PIN1, OUTPUT);
	DIO_VidSetPinDirection(PORTB, PIN2, OUTPUT);
	DIO_VidSetPinValue(PORTB, PIN2, HIGH);

	while(1)
	{
		DIO_VidSetPinValue(PORTB, PIN0, HIGH);
		_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
			DIO_VidSetPinValue(PORTB, PIN0, LOW);
			_delay_ms(5);
	}


}
