#ifndef _TCNT0_INTERFACE_H_
#define _TCNT0_INTERFACE_H_


#define ISR_ADC()  void __vector_10(void)__attribute__((signal));\
	               void __vector_10(void)





void TCNT0_INIT(void);
void TCNT1_INIT(void);
void TCNT2_INIT(void);

void TCNT_INIT(void);

void TCNT0_SetCallBack(void (*LocalPFunc)(void));
















#endif
