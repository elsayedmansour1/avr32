#ifndef _GIE_REGISTER_H_
#define _GIE_REGISTER_H_



#define SREG    *((volatile u8*)0x5F)




#endif