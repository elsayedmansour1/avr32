#ifndef _GIE_INTERFACE_H_
#define _GIE_INTERFACE_H_





void SREG_VidEnable(void);
void SREG_VidDisable(void);



















#endif