/*
 * main.c
 *
 *  Created on: Jun 27, 2020
 *      Author: elsay
 */


#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"GIE_Interface.h"
#include"TCNT0_Interface.h"
#include"LCD_Interface.h"
#include"TCNT0_Define.h"


void TIMER_Func(void);

void clock(void);



void main(void)
{
	DIO_VidSetPinDirection(PORTC,PIN1,OUTPUT);
	TCNT0_INIT();
	SREG_VidEnable();
	LCD_VidInit();
	TCNT0_SetCallBack(TIMER_Func);
	GoToXY(0,0);
	LCD_VidWriteString("HH:MM:SS");
	GoToXY(1,0);
	LCD_VidWriteString("00:00:00");
	while(1)
	{

	}
}






void TIMER_Func(void)
{

	static u16 counter=0;

	counter++;
	if(counter==3907)
	{
		DIO_VidSetPinValue(PORTC,PIN1,1);
		clock();
		counter=0;
	}
}





void clock(void)
{
	static u8 SECOND=0;
	SECOND++;
	static u8 hour=0;
	static u8 minute=0;
	if(SECOND<=9)
	{
		GoToXY(1,7);
		LCD_VidWriteNumber(SECOND);
	}
	else if(SECOND>9 && SECOND<=60)
	{
		GoToXY(1,6);
		LCD_VidWriteNumber(SECOND);
	}
	else
	{
		SECOND=0;
		GoToXY(1,6);
		LCD_VidWriteNumber(SECOND);
		minute++;
	}
	if(minute!=0)
	{
		if(minute<=9)
		{
			GoToXY(1,4);
			LCD_VidWriteNumber(minute);
		}
		else if(minute>9 && minute<=60)
		{
			GoToXY(1,3);
			LCD_VidWriteNumber(minute);
		}
		else
		{
			minute=0;
			GoToXY(1,3);
			LCD_VidWriteNumber(minute);
			hour++;
		}
	}
	if(hour!=0)
		{
			if(hour<=9)
			{
				GoToXY(1,1);
				LCD_VidWriteNumber(hour);
			}
			else if(hour>9 && hour<=60)
			{
				GoToXY(1,0);
				LCD_VidWriteNumber(hour);
			}
			else
			{
				hour=0;
				GoToXY(1,0);
				LCD_VidWriteNumber(hour);
			}
		}
}
