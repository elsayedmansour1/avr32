/*
 * LDR.h
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */


#ifndef _LDR_H_
#define _LDR_H_



void ADC_LDR(void);
void LDR (u8 *ptr1, u8 *ptr2);




#endif
