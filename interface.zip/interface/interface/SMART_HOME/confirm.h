/*
 * confirm.h
 *
 *  Created on: Jul 22, 2020
 *      Author: elsay
 */


u8 Confriming_System(u8 *ptr1,u8 *ptr2,u8 correct);
u8 Correct_ID(u8 *ptr1,u8 *ptr2,u8 correct);
u8 Correct_PASSWORD(u8 *ptr1,u8 *ptr2,u8 correct);
void NOT_CORRECT(u8 counter_wrong);
