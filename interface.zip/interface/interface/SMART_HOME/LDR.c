/*
 * LDR.c
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */


#include"STD_TYPES.h"
#include"BIT_Math.h"
#include "util/delay.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"ADC_Interface.h"
#include"ADC_Register.h"
#include"GIE_Interface.h"
#include"LDR.h"
#include"func.h"

u8  flag1=0;
u16 digital_value2=0;
u8  DARK=0;
u8  LIGHT=0;
void ADC_LDR(void)
{
	flag1=1;
}
void LDR (u8 *ptr1, u8 *ptr2)
{
	LCD_VidWriteCommend(1);
	ADC_INIT();									//ADC Initialization

	GIE_VidEnable();							//Global Interrupt Enable
	ADC_SetCallBack(ADC_LDR);					//Address for ADC Function
	ADC_GET_RESULT();
	u8 data=0;

	ADC_CHECKMODE(INTERRUPT);
	ADC_SELECT_CHANNAL(ADC1);
	StartConversion();
	while(flag1==1)
	{
		data=UART_Recive();

				digital_value2=(ADC*5)/1023;
				DARK=(digital_value2*100)/4;
				LIGHT=100-DARK;
				LCD_GoToXY(0,0);
				LCD_VidWriteString("LDR")	;
				LCD_GoToXY(0,7);
				LCD_VidWriteString("LED:")	;

				LCD_GoToXY(1,0);
				LCD_VidWriteString("LIGHT=");
				LCD_VidWriteNumber(LIGHT);
				LCD_GoToXY(1,9);
				LCD_VidWriteData('%');
				if(LIGHT<25)
				{
					DIO_VidSetPinValue(PORTC,PIN7,HIGH);
					LCD_GoToXY(0,11);
					LCD_VidWriteString("ON")	;
				}
				else
				{
					DIO_VidSetPinValue(PORTC,PIN7,LOW);
					LCD_GoToXY(0,11);
					LCD_VidWriteString("OFF")	;

				}
				_delay_ms(500);
				LCD_CLEAR(0,11,15);
				LCD_CLEAR(1,6,9);

			if(data=='m')
			{
				flag1=0;
				Interrupt_Disable();
				LCD_VidWriteCommend(1);
				StartScreen();
				*ptr1=0;
				*ptr2=0;
			}

	}
}
