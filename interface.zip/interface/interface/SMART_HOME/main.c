/*
 * main.c
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include "util/delay.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"ADC_Interface.h"
#include"ADC_Register.h"
#include"GIE_Interface.h"
#include"LM_35.h"
#include"LDR.h"
#include"func.h"

void main(void)
{
	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX

	LCD_VidInit();								//LCD Initialization
	UART_INIT();								//USART Initialization

		u8 data=0;
		u8 confirm1=0;
		u8 confirm2=0;
		u8 *ptr1=&confirm1;
		u8 *ptr2=&confirm2;
		u8 customChar[] = {0x10,0x18,0x1C,0x1E,0x1C,0x18,0x10,0x00};

		LCD_VidWriteString("   welcome ");
		_delay_ms(1000);
		LCD_VidWriteCommend(1);
		StartScreen();
		while(1)
		{
			data=UART_Recive();
            Controll(data,ptr1);
			Controll2(data,ptr2);

		    if (confirm1==1 && confirm2==1)
			{

				LM_35(&confirm1,&confirm2);

			}
		    else if (confirm1==2 && confirm2==1)
		    {
		    	LDR (&confirm1,&confirm2);
		    }


		}
}
