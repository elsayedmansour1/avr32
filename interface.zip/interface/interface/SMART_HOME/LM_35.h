/*
 * LM_35.h
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */

#ifndef _LM_35_H_
#define _LM_35_H_



void ADC_LM_35(void);
void LM_35 (u8 *ptr1, u8 *ptr2);




#endif
