/*
 * LM_35.C
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include "util/delay.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"ADC_Interface.h"
#include"ADC_Register.h"
#include"GIE_Interface.h"
#include"LM_35.h"
#include"func.h"

u8 flag=0;
u16 digital_value;
u8 temp;
void ADC_LM_35(void)
{
	flag=1;
}
void LM_35 (u8 *ptr1, u8 *ptr2)
{
	LCD_VidWriteCommend(1);
		ADC_INIT();									//ADC Initialization

		GIE_VidEnable();							//Global Interrupt Enable
		ADC_SetCallBack(ADC_LM_35);					//Address for ADC Function
		ADC_GET_RESULT();

		u8 data=0;

		ADC_CHECKMODE(INTERRUPT);
		ADC_SELECT_CHANNAL(ADC0);
		StartConversion();
		while(flag==1)
		{


				digital_value=( ADC *5000UL)/1023;
				temp=digital_value/10;

				LCD_GoToXY(0,0);
				LCD_VidWriteString("LM-35")	;

				LCD_GoToXY(0,8);
				LCD_VidWriteString("BUZZER:")	;



				LCD_GoToXY(1,0);
				LCD_VidWriteString("TEMP=");
				LCD_VidWriteNumber(temp);
				LCD_VidWriteString("C");
				if(temp>40)
				{
					DIO_VidSetPinValue(PORTC,PIN6,HIGH);
					LCD_GoToXY(1,10);
					LCD_VidWriteString("ON")	;
				}
				else
				{
					DIO_VidSetPinValue(PORTC,PIN6,LOW);
					LCD_GoToXY(1,10);
					LCD_VidWriteString("OFF")	;

				}
				_delay_ms(500);
				LCD_CLEAR(1,10,15);

				data=UART_Recive();
				if(data=='m')
				{
					LCD_VidWriteCommend(1);
					StartScreen();
					Interrupt_Disable();
					GIE_VidDisable();
					flag=0;
					*ptr1=0;
					*ptr2=0;
				}

		}

}
