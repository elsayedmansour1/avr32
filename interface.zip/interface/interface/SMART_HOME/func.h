/*
 * func.h
 *
 *  Created on: Jul 25, 2020
 *      Author: elsay
 */


void SYSTEM_LOADING(void);
void StartScreen(void);
void Controll(u8 data,u8*ptr1);
void Controll2(u8 data,u8*ptr2);
