/*
 * main.c
 *
 *  Created on: Aug 17, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
//#include"ADC_Interface.h"
#include"arrray_of_sound.h"

u16 flex_sensor1(void);
u16 flex_sensor2(void);
u16 flex_sensor3(void);
u16 flex_sensor4(void);
u16 flex_sensor5(void);

void main(void)
{
				/*DIRECTION*/
/*	DIO_VidSetPinDirection(PORTC, PIN0, INPUT);
	DIO_VidSetPinDirection(PORTC, PIN1, INPUT);
	DIO_VidSetPinDirection(PORTC, PIN7, INPUT);
	DIO_VidSetPortDirection(PORTB, OUTPUT);
				/*VALUE*/
	//DIO_VidSetPinValue(PORTC, PIN0, HIGH);
	//DIO_VidSetPinValue(PORTC, PIN1, HIGH);
			/*Initialization*/
	LCD_VidInit();                               //LCD Initialization
	//ADC_INIT();									//ADC Initialization
			/*VARIABLE DEFINATION*/
	u16 value1=0;
	u16 value2=0;
	u16 value3=0;
	u16 value4=0;
	u16 value5=0;


	LCD_VidWriteString("WELLCOME ELSAYED");

	_delay_ms(2000);
	LCD_VidWriteCommend(1);                     //clear LCD

	//StartConversion();
	//ADC_CHECKMODE(POLLING);

	while(1)
	{

		/*DIO_VidSetPinValue(PORTC, PIN7, LOW);
		DIO_VidSetPinValue(PORTC, PIN6, LOW);

			value1=flex_sensor1();
			value2=flex_sensor2();
			value3=flex_sensor3();
			value4=flex_sensor4();
			value5=flex_sensor5();



			if(value1>4500)
			{
				DIO_VidSetPinValue(PORTC, PIN7, HIGH);
				_delay_ms(100);
				DIO_VidSetPinValue(PORTC, PIN7, LOW);
				_delay_ms(100);
			}
			if(value2>4500)
			{
				DIO_VidSetPinValue(PORTC, PIN6, HIGH);
				_delay_ms(100);
				DIO_VidSetPinValue(PORTC, PIN6, LOW);
				_delay_ms(100);
			}*/
		for(u16 i=0;i<20000;i++)
		{
			DIO_VidSetPortValue(PORTB, arr[i]);
		}
	}//end of endless loop
}//end of code

/*u16 flex_sensor1(void)
{
	ADC_SELECT_CHANNAL(ADC0);
	u16 digital_value=0;
	u16 analog_value=0;

	digital_value=ADC_GET_RESULT();
	analog_value=(digital_value*5000UL)/1024;

return analog_value;
}
u16 flex_sensor2(void)
{

	ADC_SELECT_CHANNAL(ADC1);
	u16 digital_value=0;
	u16 analog_value=0;

	digital_value=ADC_GET_RESULT();
	analog_value=(digital_value*5000UL)/1024;

return analog_value;
}
u16 flex_sensor3(void)
{
	ADC_SELECT_CHANNAL(ADC2);
	u16 digital_value=0;
	u16 analog_value=0;

	digital_value=ADC_GET_RESULT();
	analog_value=(digital_value*5000UL)/1024;

return analog_value;
}
u16 flex_sensor4(void)
{

	ADC_SELECT_CHANNAL(ADC3);
	u16 digital_value=0;
	u16 analog_value=0;

	digital_value=ADC_GET_RESULT();
	analog_value=(digital_value*5000UL)/1024;

return analog_value;
}
u16 flex_sensor5(void)
{
	ADC_SELECT_CHANNAL(ADC4);
	u16 digital_value=0;
	u16 analog_value=0;

	digital_value=ADC_GET_RESULT();
	analog_value=(digital_value*5000UL)/1024;

return analog_value;
}*/
/*
 			value1=flex_sensor1();
			LCD_GoToXY(0, 0);
			LCD_VidWriteString("value1=");
			LCD_GoToXY(0, 7);
			LCD_VidWriteNumber(value1);
			_delay_ms(100);


			value2=flex_sensor2();
			LCD_GoToXY(1, 0);
			LCD_VidWriteString("value2=");
			LCD_GoToXY(1, 7);
			LCD_VidWriteNumber(value2);
			_delay_ms(50);
 */
