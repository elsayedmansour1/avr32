/*
 * main.c
 *
 *  Created on: Jun 5, 2020
 *      Author: elsay
 */
#include"BIT_MATH.H"
#include"STD_TYPES.H"
#include"DIO_Interface.h"
#include"7SEG_Interface.h"
#include<avr/delay.h>

void main (void)
{
	SEG_VidCount(PORTA,CATHOD,UP);
}
