#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"
#include"LCD_Interface.h"

void KEYPAD_VidInit(void)
{
	DIO_VidSetPortDirection ( PORTA,0B00001111);
	DIO_VidSetPortValue	( PORTA, 0B11111111);
}
u8 GET_PressedKey(void)
{   u8 keypad_array[4][4]={{1,2,3,4},
		                   {5,6,7,8},
						   {9,10,11,12},
						   {13,14,15,16}};
	u8 col,row;
	u8 keypad_out=0;

	for(col=0;col<4;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
		for(row=4;row<8;row++)
		{
			if(DIO_vidGitPinValue(PORTA,row)==0)
			{

				keypad_out= keypad_array[row-4][col];
				while(DIO_vidGitPinValue(PORTA,row)==0)
				{
					
				}
				_delay_ms(50);
			}



		}
		DIO_VidSetPinValue	( PORTA, col, 1);
	}

return keypad_out;
}
u8 Keypad_nokia(u8 counter)
{
	   /*u8 keypad_array[4][4]={{1,2,3},
			                  {4,5,6},
							  {7,8,9}};*/
	   u8 keypad_array2[3][3][4]={{{49,49,49,49},{50,65,66,67},{51,68,69,70}},
	   	   	   	   	   	   	   	  {{52,71,72,73},{53,74,75,76},{54,77,78,79}},
	                              {{55,80,81,82},{56,83,84,85},{57,86,87,88}}};
	   //{58,89,90,91},{59,92,93,94},{60,95,96,97}
		u8 col,row;
		u8 keypad_out=0;

		for(col=0;col<3;col++)
		{
			DIO_VidSetPinValue	( PORTA, col, 0);
			for(row=4;row<7;row++)
			{
				if(DIO_vidGitPinValue(PORTA,row)==0)
				{

					keypad_out= keypad_array2[row-4][col][counter];
					while(DIO_vidGitPinValue(PORTA,row)==0)
					{

					}
					_delay_ms(50);
				}



			}
			DIO_VidSetPinValue	( PORTA, col, 1);
		}

	return keypad_out;

}
u8 Keypad_counter_clear(void)
{
	u8 keypad_out=0;
	DIO_VidSetPinValue	( PORTA, 3, 0);

	if(DIO_vidGitPinValue(PORTA,7)==0)
	{

		keypad_out=1;
		while(DIO_vidGitPinValue(PORTA,7)==0)
		{

		}
		_delay_ms(30);
	}
	DIO_VidSetPinValue	( PORTA, 3, 1);
	return keypad_out;
}
u8 Keypad_controll1(void)
{
	u8 keypad_out=0;
	u8 value[]={4,5,6};
	for(u8 col=0;col<3;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
			if(DIO_vidGitPinValue(PORTA,5)==0)
			{

			keypad_out=value[col];
			while(DIO_vidGitPinValue(PORTA,5)==0)
			{

			}
			_delay_ms(30);
			}
	   DIO_VidSetPinValue	( PORTA, col, 1);
	}
	return keypad_out;
}
u8 Keypad_controll2(void)
{
	u8 keypad_out=0;
	u8 value[]={1,2,3};
	for(u8 col=0;col<3;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
			if(DIO_vidGitPinValue(PORTA,4)==0)
			{

			keypad_out=value[col];
			while(DIO_vidGitPinValue(PORTA,4)==0)
			{

			}
			_delay_ms(30);
			}
	   DIO_VidSetPinValue	( PORTA, col, 1);
	}
	return keypad_out;
}
