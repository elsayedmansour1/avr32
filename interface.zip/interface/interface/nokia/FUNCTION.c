/*
 * FUNCTION.C
 *
 *  Created on: Jul 9, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include "Keypad_Interface.h"
#include "FUNCTION.h"



void Password (void)
{
	u8 Keypad_Out=0;
	u8 counter=0;
	u8 counter1=0;
	u8 counter_clear=0;
	u8 space=0;
	u8 incorrect=0;
	u8 size_arr=0;
	u8 password[5];
	u8 ID[5];
	u8 correct_pass[]={65,68,77,73,78};

	while(incorrect<3)
	{
		LCD_GoToXY(0,0);
		LCD_VidWriteString("Password:");

		Keypad_Out=Keypad_nokia(counter);
		counter_clear=Keypad_counter_clear();


		if(Keypad_Out!=0)
		{
			password[size_arr]=Keypad_Out;
			LCD_GoToXY(0,space+9);
			LCD_VidWriteData(Keypad_Out);
            counter++;

            if(counter==4)
            {
            	counter=0;
            }
		}
		else if(counter_clear!=0)
		{
			if(counter_clear==1)
			{
				counter=0;
				LCD_GoToXY(0,space+9);
				LCD_VidWriteData('*');
				space++;
				size_arr++;
			}
		}
		if(size_arr==5)
			{
                    space=0;
					for(u8 x=0;x<size_arr;x++)
					{

						if(password[x]==correct_pass[x])
						{
							counter1++;
						}

					}

					if(counter1==size_arr)
					{
						LCD_GoToXY(1,0);
						LCD_VidWriteString("CORRECT_PASS");
						_delay_ms(1000);
						size_arr=0;
						LCD_VidWriteCommend(1);
						break;
					}
					else if(counter1!=size_arr)
					{
						LCD_GoToXY(1,0);
						LCD_VidWriteString("INCORRECT_PASS");
						_delay_ms(500);
						LCD_CLEAR(1,0,15);
						LCD_GoToXY(1,0);
						LCD_VidWriteString("TRY AGAIN");
						_delay_ms(500);
						size_arr=0;
						incorrect++;
						LCD_VidWriteCommend(1);
					}
				}



	}

}
void ID (void)
{
	u8 Keypad_Out=0;
	u8 counter=0;
	u8 counter1=0;
	u8 counter_clear=0;
	u8 space=0;
	u8 incorrect=0;
	u8 size_arr=0;
	u8 ID[5];
	u8 correct_ID[]={65,68,77,73,78};
	while(incorrect<3)
	{
		LCD_GoToXY(0,0);
		LCD_VidWriteString("ID:");

		Keypad_Out=Keypad_nokia(counter);
		counter_clear=Keypad_counter_clear();


		if(Keypad_Out!=0)
		{
			ID[size_arr]=Keypad_Out;
			LCD_GoToXY(0,space+3);
			LCD_VidWriteData(Keypad_Out);
            counter++;

            if(counter==4)
            {
            	counter=0;
            }
		}
		else if(counter_clear!=0)
		{
			if(counter_clear==1)
			{
				counter=0;
				space++;
				size_arr++;
			}
		}
		if(size_arr==5)
			{
                    space=0;
					for(u8 x=0;x<size_arr;x++)
					{

						if(ID[x]==correct_ID[x])
						{
							counter1++;
						}

					}

					if(counter1==size_arr)
					{
						LCD_GoToXY(1,0);
						LCD_VidWriteString("CORRECT_ID");
						_delay_ms(1000);
						size_arr=0;
						LCD_VidWriteCommend(1);
						break;
					}
					else if(counter1!=size_arr)
					{
						LCD_GoToXY(1,0);
						LCD_VidWriteString("INCORRECT_ID");
						_delay_ms(500);
						LCD_CLEAR(1,0,15);
						LCD_GoToXY(1,0);
						LCD_VidWriteString("TRY AGAIN");
						_delay_ms(500);
						size_arr=0;
						incorrect++;
						LCD_VidWriteCommend(1);
					}
				}



	}

}

void SYSTEM_LOADING(void)
{
	LCD_GoToXY(0,0);
	LCD_VidWriteString("SYSTEM_LOADING");
	LCD_GoToXY(1,0);
	for(u8 x=0;x<15;x++)
	{
		LCD_VidWriteData('>');
		_delay_ms(100);
	}

}
void StartScreen(void)
{
	                LCD_GoToXY(0,1);
					LCD_VidWriteString("1-LM-35");
					LCD_GoToXY(0,11);
					LCD_VidWriteString("2-LDR");
					LCD_GoToXY(1,1);
					LCD_VidWriteString("3-DC_MOTOR");
}
