/*
 * FUNCTION.H
 *
 *  Created on: Jul 9, 2020
 *      Author: elsay
 */

void Password (void);
void ID (void);
void SYSTEM_LOADING(void);
void StartScreen(void);
