/*
 * main.c
 *
 *  Created on: Jul 8, 2020
 *      Author: elsay
 */


#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include "Keypad_Interface.h"
#include "FUNCTION.h"


void main(void)
{
	KEYPAD_VidInit();
	LCD_VidInit();
 u8 value=0;
 u8 value1=0;
 u8 result=0;
 u8 result1=0;
 u8 customChar[] = {   0x10,   0x18,   0x1C,   0x1E,   0x1C,   0x18,   0x10,   0x00 };
	ID();
	Password();
	LCD_VidWriteString("Wellcome Elsayed");
	_delay_ms(1000);
	LCD_VidWriteCommend(1);
	SYSTEM_LOADING();
	LCD_VidWriteCommend(1);
	StartScreen();
	while(1)
	{
		value=Keypad_controll2();
		value1=Keypad_controll1();
		if(value1!=0)
		{
			result1=value1;
			if(value1==4&&result1==4)
			{
				LCD_CLEAR( 1,  0,  1);
				LCD_CLEAR( 0, 10, 11);
				LCD_CONSTANT(customChar, 8, 0, 0, 1);
			}
			else if(value1==5&&result1==5)
			{
				LCD_CLEAR( 1, 0, 1);
				LCD_CLEAR( 0, 0, 1);
				LCD_CONSTANT(customChar, 8, 0, 10, 1);
			}
			else if(value1==6&&result1==6)
			{
				LCD_CLEAR( 0,  0,  1);
				LCD_CLEAR( 0, 10, 11);
				LCD_CONSTANT(customChar, 8, 1, 0, 1);
			}

		}
		else if(value!=0)
		{
			result=value;
			LCD_VidWriteCommend(1);
			_delay_ms(500);
		}
		else{}

		if(result==1 && result1==4)
		{
            LCD_GoToXY(0, 0);
			LCD_VidWriteString("LM-35");
			//LM_35_SENSOR(ADC0,POLLING,1);
		}
		else if(result==1 && result1==5)
	    {
			LCD_GoToXY(0, 0);
			LCD_VidWriteString("LDR");
			//LDR_SENSOR(ADC1,POLLING,1);
		}
		else if(result==1 && result1==6)
		{
			LCD_GoToXY(0, 0);
			LCD_VidWriteString("DC-MOTOR");
		}
	}

}


