#ifndef _KEYPAD_INTERFACE_H_
#define _KEYPAD_INTERFACE_H_





void KEYPAD_VidInit(void);

u8 GET_PressedKey(void);

u8 GET_PressedKeyNew(void);

s8 KEYPAD_VidCal(u8 x,u8 ch);

u8 Keypad_nokia(u8 counter);

u8 Keypad_counter_clear(void);

u8 Keypad_controll1(void);

u8 Keypad_controll2(void);















#endif
