/*
 * main.c
 *
 *  Created on: Jun 12, 2020
 *      Author: elsay
 */

#include "STD_TYPES.h"
#include "DIO_Interface.h"
#include "BIT_Math.h"
#include<avr/delay.h>
void main(void)
{
	DIO_VidSetPinDirection(PORTA,PIN0,OUTPUT);
	DIO_VidSetPinDirection(PORTA,PIN1,OUTPUT);

	while(1)
	{
		DIO_VidSetPinValue(PORTA,PIN0,1);
		_delay_ms(3000);
		DIO_VidSetPinValue(PORTA,PIN0,0);
			_delay_ms(3000);
		DIO_VidSetPinValue(PORTA,PIN1,1);
		_delay_ms(3000);
		DIO_VidSetPinValue(PORTA,PIN1,0);
		_delay_ms(3000);
	}
}
