/*
 * main.c
 *
 *  Created on: Jul 6, 2020
 *      Author: elsay
 */

void T2_IC(void);

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<util/delay.h>
#include"DIO_Interface.h"
#include"GIE_Interface.h"
#include"TIMER_Interface.h"
#include"LCD_Interface.h"
#include"EXIT_Interface.h"
#include"TIMER_Register.h"
#include"TIMER1_Define.h"
#include"TIMER0_Define.h"

u8 Ton=0;
u8 Toff=0;
u16 Ttotal=0;
f32 DUTY_CYCLE=0;
f32 x=0;
f32 DROW_UP=0;
u8 DROW_DOWN=0;
u8 Flag=0;
u8 OVF=0;
u16 snap1=0;
u16 snap2=0;
u16 snap3=0;
void main(void)
{
	u8 CULOM[] = {0x10,	 0x10,	 0x10,		0x10,	 0x10,	0x10,	0x10,	0x10	};
	u8 CULOM0[] = {0x1F,   0x10,   0x10,	  0x10,	  0x10,   0x10,   0x10,   0x10  };
	u8 CULOM1[] = {	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x1F	};
	u8 ROW[]   = {0x1F,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00	};
	u8 ROW0[]   = {0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	 0x1F, 0x00	 	};

	DIO_VidSetPinDirection(PORTB,PIN3,OUTPUT);
	DIO_VidSetPinDirection(PORTD,PIN6,INPUT);

	T2_IC_SetCallBack(T2_IC);

	TIMER1_INIT();

	GIE_VidEnable();
	LCD_VidInit();
	TIMER0_INIT();

	SET_BIT(TCCR1B,ICES1);                 //Rising Edge;
	TIMER1_Input_Capture_Enable();

	Set_Duty_Cycle(30);

	while(1)
	{
		if(Flag==3)
		{  /* GoToXY(0,0);
		    Ton=snap2-snap1;
			LCD_VidWriteString("Ton=");
			LCD_VidWriteNumber(Ton);
			Toff=snap3-snap2;
			Ttotal=Ton+Toff;
			GoToXY(1,0);
			LCD_VidWriteString("Ttotal=");
			LCD_VidWriteNumber(Ttotal);
			Flag=0;*/
			    Ton=snap2-snap1;
				Toff=snap3-snap2;
				Ttotal=Ton+Toff;
				DROW_UP=(Ton*14.0)/255.0;
				DROW_DOWN=14-DROW_UP;
				LCD_CONSTANT(CULOM0,0,0,0,0);

				for(u8 i=1;i<DROW_UP;i++)
				{
				LCD_CONSTANT(ROW,8,0,i,1);
				}

				LCD_CONSTANT(CULOM,16,0,DROW_UP+1,2);

				//LCD_VidWriteNumber(DROW_UP);

				for(u8 i=DROW_UP+2;i<DROW_DOWN+7;i++)
				{
					LCD_CONSTANT(ROW0,24,0,i,3);
				}
				//LCD_VidWriteNumber(Ton);
		}
	}
}



void T2_IC(void)
{
	if(Flag==0)
	{
		snap1=ICR1A;
		CLR_BIT(TCCR1B,ICES1);         //Falling Edge;
		Flag=1;

	}
	else if(Flag==1)
	{
		snap2=ICR1A;
		SET_BIT(TCCR1B,ICES1);        //Rising Edge;
		Flag=2;
	}
	else if(Flag==2)
	{
		snap3=ICR1A;

		Flag=3;
	}
}
