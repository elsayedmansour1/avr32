#ifndef _EXIT_INTERFACE_H_
#define _EXIT_INTERFACE_H_

#define INT0  0
#define INT1  1
#define INT2  2

#define FALLING_EDGE  0
#define RISING_EDGE   1
#define ON_CHANGE     2
#define LOW_LEVEL     3

  
#define SENCE_MOOD0  RISING_EDGE  // INTERRUPT 0
#define SENCE_MOOD1  FALLING_EDGE // INTERRUPT 1
#define SENCE_MOOD2  FALLING_EDGE // INTERRUPT 2

#define ISR_EXINT_2()    void __vector_3(void)__attribute__((signal));\
	               void __vector_3(void)

void EXTINT_VidINT(u8 LOC_u8INT_NUM);
void EXTINT_VidDisable(u8 LOC_u8INT_NUM);
void EXTINT_VidEnable(u8 LOC_u8INT_NUM);
void EXIT2(u8 Sense_Mode);

void EXIT2_SetCallBack(void (*LocalPFunc)(void));













#endif
