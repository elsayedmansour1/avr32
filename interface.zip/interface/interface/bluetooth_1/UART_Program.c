#include "STD_TYPES.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"UART_Interface.h"
#include"Vector.h"

void (*GPFUNC)(void)=NULL;

void RX_SetCallBack(void (*LOCFUNC)(void))
{
GPFUNC=LOCFUNC;
}

ISR_USART_RXC()
{
	GPFUNC();
}
u8 Temporary_REG=0;
void USART_INIT(void)
{
     /*enable*/
	Receiver_Enable;
	Transmitter_Enable;
	//Receiver_Interrupt_Enable;

	USCRC=Temporary_REG;
	
	UBRRH=0;
	UBRRL=51;



}

void USART_Transmit (u8 SEND)
{
	while(!GET_BIT(USCRA,UDRE)){}
	UDR=SEND;
}

u8 USART_Receive (void)
{
	u8 result=0;
	while(!GET_BIT(USCRA,RXC)){}
	result=UDR;

	return result;
}
