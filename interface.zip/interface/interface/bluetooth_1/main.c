/*
 * main.c
 *
 *  Created on: Jul 12, 2020
 *      Author: elsay
 */
void RXC_FUNC(void);

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"ADC_Interface.h"
#include"ADC_Register.h"
#include"Function.h"
#include"TIMER_Interface.h"
#include"UART_Interface.h"
#include"LCD_Interface.h"
#include"DIO_Interface.h"
#include"GIE_Interface.h"
#include "Keypad_Interface.h"

void LM_35_SENSOR (void);

u8 flag=0;
u8 flag1=0;

void main(void)
{
	u8 value=0;
	GIE_VidEnable();
	ADC_SetCallBack(LM_35_SENSOR);
	u8 choose1=0;
	u8 choose=0;
    u8 end=0;
	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX
	DIO_VidSetPinDirection(PORTD,PIN7,OUTPUT);  //motor
	DIO_VidSetPinDirection(PORTC,PIN7,OUTPUT);


				/*Initialization*/

	LCD_VidInit();                               //LCD Initialization
	USART_INIT();                                //USART Initialization
	TIMER2_INIT();								//TIMER2 Initialization
	ADC_INIT();									//ADC Initialization


	LCD_VidWriteString("WELLCOME ELSAYED");

	_delay_ms(1000);
	LCD_VidWriteCommend(1);                     //clear LCD



	ID();
	PASSWORD();
	StartScreen();

	ADC_CHECKMODE(INTERRUPT);
	ADC_GET_RESULT();
while(1)
{
	if(choose==0)
	{
		while(choose==0)
		{
			choose=Controll();
		}
	}
	elsayed(choose1);

	        if(choose==1)
			{

	        	choose1++;
	        	TOG_BIT( *((volatile u8*)0x35),PIN7);
	        	flag=1;
	        	 StartConversion();
	        	_delay_ms(100);



			}
			else if(choose==2)
			{
				flag=2;
				ADC_SELECT_CHANNAL(ADC1);

			}
			else if(choose==3)
			{
				DC_MOTOR();
			}
			else{}
	        if(end==1)
	        {
	        	LCD_VidWriteCommend(1);                     //clear LCD
	        	StartScreen();
	        	choose=0;
	        }

}
}
void LM_35_SENSOR (void)
{

	if(flag==1)
	{

		u16 digital_value;
		u8 temp;


	    digital_value=( ADC *5000UL)/1024;
	    temp=digital_value/10;

	    	LCD_GoToXY(0,0);
			LCD_VidWriteString("LM-35")	;

			LCD_GoToXY(0,8);
			LCD_VidWriteString("BUZZER:")	;



			LCD_GoToXY(1,0);
			LCD_VidWriteString("TEMP=");
			LCD_VidWriteNumber(temp);
			LCD_VidWriteString("C");
			if(temp>40)
			{
				LCD_GoToXY(1,10);
				LCD_VidWriteString("ON")	;
			}
			else
			{
				LCD_GoToXY(1,10);
				LCD_VidWriteString("OFF")	;
			}
			_delay_ms(500);
			LCD_CLEAR(1,10,15);

	}
	else if(flag==2)
	{
			u16 digital_value2=0;
			u8 DARK=0;
			u8 LIGHT=0;
			digital_value2=(ADC*5)/1024;
			DARK=(digital_value2*100)/4;
			LIGHT=100-DARK;
			LCD_GoToXY(0,0);
			LCD_VidWriteString("LDR")	;
			LCD_GoToXY(0,7);
			LCD_VidWriteString("LED:")	;

			LCD_GoToXY(1,0);
			LCD_VidWriteString("LIGHT=");
			LCD_VidWriteNumber(LIGHT);
			LCD_GoToXY(1,9);
			LCD_VidWriteData('%');
			if(LIGHT<25)
			{
				DIO_VidSetPinValue(PORTB,PIN5,HIGH);
				LCD_GoToXY(0,11);
				LCD_VidWriteString("ON")	;
			}
			else
			{
				DIO_VidSetPinValue(PORTB,PIN5,LOW);
				LCD_GoToXY(0,11);
				LCD_VidWriteString("OFF")	;

			}
			_delay_ms(500);
			LCD_CLEAR(0,11,15);
			LCD_CLEAR(1,6,9);
	}




}

