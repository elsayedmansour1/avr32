#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "TIMER_Register.h"
#include "TIMER_Interface.h"
#include"TIMER0_Define.h"
#include"TIMER1_Define.h"
#include"TIMER2_Define.h"
#include "Vector.h"



static void (*GPFunc)(void)=NULL;
void T2_IC_SetCallBack(void (*LocalPFunc)(void))
{
	GPFunc=LocalPFunc;
}
ISR_TMR1_Capt()
{
	if(GPFunc!=NULL)
	{
		GPFunc();
	}
}



/*******************************************************************************************************/
void TIMER0_INIT(void)
{
#if Timer0_Mode==Normal_Timer0_Mode
	TCNT0=0;                       //YOU SHOULD CHANGE THIS BIT
	Normal_0;
	prescaler_clk_256_0;
	Non_PWM_Normal_OC0_disconnected_0;
	Overflow_Interrupt_Enable_0;
#elif Timer0_Mode==CTC_Timer0_Mode
	OCR0=256;                     //YOU SHOULD CHANGE THIS BIT
	CTC_Mode_0;
	prescaler_clk_256_0;
	Non_PWM_Normal_OC0_disconnected_0;
	Compare_Match_Interrupt_Enable_0;
#elif Timer0_Mode==Fast_PWM_Timer0_Mode
	Fast_PWM_0;
	NonInverted_Mode_0;
	prescaler_clk_256_0;
#elif Timer0_Mode==PWM_Phase_Correct_Timer0_Mode
	PWM_Phase_Correct_0;
	prescaler_clk_256_0;

#else
#error "WRONG CHOOSE"
#endif

}
/*******************************************************************************************************/
void TIMER1_INIT(void)
{
#if Timer1_Mode==NORMAL_Timer_1
	prescaler_clk_256_1;
	NORMAL;
	Normal_port_operation_1;
#elif Timer1_Mode==PWM_Phase_Correct_8_bit_Timer_1
#elif Timer1_Mode==PWM_Phase_Correct_9_bit_Timer_1
#elif Timer1_Mode==PWM_Phase_Correct_10_bit_Timer_1
#elif Timer1_Mode==CTC_1_Timer_1
#elif Timer1_Mode==Fast_PWM_8_bit_Timer_1
#elif Timer1_Mode==Fast_PWM_9_bit_Timer_1
#elif Timer1_Mode==Fast_PWM_10_bit_Timer_1
#elif Timer1_Mode==PWM_Phase_and_Frequency_Correct_1_Timer_1
#elif Timer1_Mode==PWM_Phase_and_Frequency_Correct_2_Timer_1
#elif Timer1_Mode==PWM_Phase_Correct_0_Timer_1
#elif Timer1_Mode==PWM_Phase_Correct_1_Timer_1
#elif Timer1_Mode==CTC_2_Timer_1
#elif Timer1_Mode==Reserved_Timer_1
#elif Timer1_Mode==Fast_PWM_0_Timer_1
	ICR1=625;
	prescaler_clk_256_1;
	Fast_PWM_10;
	PWM_Non_Inverted_1;
#elif Timer1_Mode==Fast_PWM_1_Timer_1
#else
#error "WRONG CHOOSE"
#endif

}
/*******************************************************************************************************/
void TIMER2_INIT(void)
{
#if Timer2_Mode==Normal_Timer2_Mode
	                             //YOU SHOULD CHANGE THIS BIT
	Normal_2;
	prescaler_clk_256_2;
	Non_PWM_Normal_OC0_disconnected_2;
	Overflow_Interrupt_Enable_2;
#elif Timer2_Mode==CTC_Timer2_Mode
	OCR2=256;                     //YOU SHOULD CHANGE THIS BIT
	CTC_Mode_2;
	prescaler_clk_256_2;
	Non_PWM_Normal_OC0_disconnected_2;
	Compare_Match_Interrupt_Enable_2;
#elif Timer2_Mode==Fast_PWM_Timer2_Mode
	Fast_PWM_2;
	NonInverted_Mode_2;
	prescaler_clk_256_2;
#elif Timer2_Mode==PWM_Phase_Correct_Timer2_Mode
	PWM_Phase_Correct_2;
	prescaler_clk_256_2;

#else
#error "WRONG CHOOSE"

#endif
}
/********************************************************************************************************/
void TIMER1_Input_Capture_Enable(void)
{
	SET_BIT(TIMSK,TICIE1);
}
/********************************************************************************************************/
void Set_Duty_Cycle(f32 Value)
{
	Value=Value/10;
	OCR2=(Value*255)-1;

}


