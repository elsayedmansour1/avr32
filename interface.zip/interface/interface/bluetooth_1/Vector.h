#ifndef _VECTOR_H_
#define _VECTOR_H_




#define ISR_EXINT0()     void __vector_1(void)__attribute__((signal));\
	                     void __vector_1(void)
#define ISR_EXINT1()     void __vector_2(void)__attribute__((signal));\
	                     void __vector_2(void)
#define ISR_EXINT2()     void __vector_3(void)__attribute__((signal));\
	                     void __vector_3(void)

#define ISR_TMR2_Comp()  void __vector_4(void)__attribute__((signal));\
	                     void __vector_4(void)
#define ISR_TMR2_Ovf()   void __vector_5(void)__attribute__((signal));\
						 void __vector_5(void)

#define ISR_TMR1_Capt()  void __vector_6(void)__attribute__((signal));\
	                     void __vector_6(void)
#define ISR_TMR1_CompA() void __vector_7(void)__attribute__((signal));\
	                     void __vector_7(void)
#define ISR_TMR1_CompB() void __vector_8(void)__attribute__((signal));\
	                     void __vector_8(void)
#define ISR_TMR1_OVF()   void __vector_9(void)__attribute__((signal));\
	                     void __vector_9(void)

#define ISR_TMR0_Comp()  void __vector_10(void)__attribute__((signal));\
	                     void __vector_10(void)
#define ISR_TMR0_OVF()   void __vector_11(void)__attribute__((signal));\
	                     void __vector_11void)

#define ISR_USART_RXC()  void __vector_13(void)__attribute__((signal));\
	                     void __vector_13(void)
#define ISR_USART_UDRE()  void __vector_14(void)__attribute__((signal));\
	                     void __vector_14(void)
#define ISR_USART_TXC()  void __vector_15(void)__attribute__((signal));\
	                     void __vector_15(void)
#endif
