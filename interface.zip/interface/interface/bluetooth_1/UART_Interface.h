#ifndef _UART_INTERFACE_H_
#define _UART_INTERFACE_H_

void RX_SetCallBack(void (*LOCFUNC)(void));

void USART_INIT(void);
void USART_Transmit (u8 SEND);
u8 USART_Receive (void);



















#endif
