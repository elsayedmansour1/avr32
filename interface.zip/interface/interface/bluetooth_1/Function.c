/*
 * Function.c
 *
 *  Created on: Jul 14, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"ADC_Interface.h"
#include"UART_Interface.h"
#include"UART_Configuration.h"
#include"LCD_Interface.h"
#include"Function.h"
#include"TIMER_Interface.h"


 u8  DATA=0;
 u8  arr[16];
 u8  corr_arr[16]={97,100,109,105,110};
 u8  arr_size=0;
 u8  counter_right=0;
 u8  counter_wrong=0;
 u8 customChar[] = {0x10,0x18,0x1C,0x1E,0x1C,0x18,0x10,0x00};

void ID(void)
{

	while(1)
	{
		LCD_GoToXY(0, 0);
		LCD_VidWriteString("ID:");
		DATA=USART_Receive();                         //Receive data from HC-o5

		    if(DATA!=13 && DATA!=10)                       //to avoid common wrong
		    {
		    	LCD_GoToXY(0, arr_size+3);
		    	LCD_VidWriteData(DATA);                  //To show the receive data on LCD
		    	USART_Transmit(DATA);   				//To send the same data to controller device
		    	arr[arr_size]=DATA;						//collect received data in array
		        arr_size++;


			if(arr_size==5)
			   {
				//LCD_GoToXY(1, 0);
				for(u8 z=0;z<5;z++)
					{
						if(arr[z]==corr_arr[z])		//check the received data is the same in corr_arr
						{
							counter_right++;
						}
					}

			   }
			if(arr_size==5 && counter_right==5)         //if the received data is the same in corr_arr
			{
				LCD_GoToXY(1, 0);
				LCD_VidWriteString("Correct");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				arr_size=0;
				counter_right=0;
				counter_wrong=0;
				break;
			}
			else if(arr_size==5 && counter_right!=5)    //if the received data isn't the same in corr_arr
			{
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Incorrect");
				_delay_ms(1000);
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Try Again");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				arr_size=0;
				counter_right=0;
				counter_wrong++;
				if(counter_wrong ==3)
				{
					LCD_VidWriteCommend(1);                        //clear LCD
					while(1)
					{
						LCD_GoToXY(0, 2);
						LCD_VidWriteString("No more Tries");
						LCD_GoToXY(1, 2);
						LCD_VidWriteString("No more Tries");
					}


				}
			}

		    }
	}
}
void PASSWORD(void)
{

	while(1)
	{
		LCD_GoToXY(0, 0);
		LCD_VidWriteString("PASSWORD:");
		DATA=USART_Receive();                         //Receive data from HC-o5

		    if(DATA!=13 && DATA!=10)                       //to avoid common wrong
		    {
		    	LCD_GoToXY(0, arr_size+9);
		    	LCD_VidWriteData(DATA);                  //To show the receive data on LCD
		    	LCD_GoToXY(0, arr_size+9);
		    	_delay_ms(200);
		    	LCD_VidWriteData('*');
		    	USART_Transmit(DATA);   				//To send the same data to controller device
		    	arr[arr_size]=DATA;						//collect received data in array
		        arr_size++;


			if(arr_size==5)
			   {
				//LCD_GoToXY(1, 0);
				for(u8 z=0;z<5;z++)
					{
						if(arr[z]==corr_arr[z])		//check the received data is the same in corr_arr
						{
							counter_right++;
						}
					}

			   }
			if(arr_size==5 && counter_right==5)         //if the received data is the same in corr_arr
			{
				LCD_GoToXY(1, 0);
				LCD_VidWriteString("Correct");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				break;
			}
			else if(arr_size==5 && counter_right!=5)    //if the received data isn't the same in corr_arr
			{
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Incorrect");
				_delay_ms(1000);
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Try Again");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				arr_size=0;
				counter_right=0;
				counter_wrong++;
				if(counter_wrong ==3)
				{
					LCD_VidWriteCommend(1);                        //clear LCD
					while(1)
					{
						LCD_GoToXY(0, 2);
						LCD_VidWriteString("No more Tries");
						LCD_GoToXY(1, 2);
						LCD_VidWriteString("No more Tries");
					}


				}
			}

		    }
	}
}
void StartScreen(void)
{
    LCD_GoToXY(0,1);
	LCD_VidWriteString("1-LM-35");
	LCD_GoToXY(0,11);
	LCD_VidWriteString("2-LDR");
	LCD_GoToXY(1,1);
	LCD_VidWriteString("3-DC_MOTOR");
}
u8 Controll(void)
{
	 u8  confirm=0;
	 u8 confirm1=0;
while(confirm1==0)
{
	DATA=USART_Receive();                         //Receive data from HC-o5

		if(DATA=='l')   																//                //
		{                                                                               //
			LCD_CLEAR( 1,  0,  1);
			LCD_CLEAR( 0, 10, 11);
			LCD_CONSTANT(customChar, 8, 0, 0, 1);
			confirm=1;
		}
		else if(DATA=='r')
		{
			LCD_CLEAR( 1, 0, 1);
			LCD_CLEAR( 0, 0, 1);
			LCD_CONSTANT(customChar, 8, 0, 10, 1);
			confirm=2;
		}
		else if(DATA=='d')
		{
			LCD_CLEAR( 0,  0,  1);
			LCD_CLEAR( 0, 10, 11);
			LCD_CONSTANT(customChar, 8, 1, 0, 1);
			confirm=3;
		}
		else if(DATA=='e')
		{
				LCD_VidWriteCommend(1);
				confirm1=confirm;
		}

}
return confirm1;

}
u8 Controll2(void)
{
	u8 confirm1=0;
	DATA=USART_Receive();                         //Receive data from HC-o5

			if(DATA=='q')   																//                //
			{
				confirm1=1;
				return confirm1;
			}
			return confirm1;
}
void elsayed(u8 choose)
{
if(choose>0)
{
	LCD_GoToXY(1,14);
	LCD_VidWriteNumber(choose);
}
}
/*void LM_35_SENSOR (u8 LOC_u8SelectChannel)
{
	u16 value2=0;
	u16 digital_value;
	u8 temp;


	value2=ADC_GET_RESULT(LOC_u8SelectChannel);
    digital_value=(value2*5000UL)/1024;
    temp=digital_value/10;

    	LCD_GoToXY(0,0);
		LCD_VidWriteString("LM-35")	;

		//LCD_GoToXY(0,8);
		//LCD_VidWriteString("BUZZER:")	;



		LCD_GoToXY(1,0);
		LCD_VidWriteString("TEMP=");
		LCD_VidWriteNumber(temp);
		LCD_VidWriteString("c");
		if(temp>40)
		{
			LCD_GoToXY(1,10);
			LCD_VidWriteString("ON")	;
		}
		else
		{
			LCD_GoToXY(1,10);
			LCD_VidWriteString("OFF")	;
		}
		_delay_ms(500);
		LCD_CLEAR(1,10,15);



}*/
/*void LDR_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus)
{
	u16 analog_value2=0;
	u16 digital_value2=0;
	u8 DARK=0;
	u8 LIGHT=0;
	analog_value2=ADC_GET_RESULT(LOC_u8SelectChannel,LOC_u8SelectStatus);
	digital_value2=(analog_value2*5)/1023;
	DARK=(digital_value2*100)/4;
	LIGHT=100-DARK;
	LCD_GoToXY(0,0);
	LCD_VidWriteString("LDR")	;
	LCD_GoToXY(0,7);
	LCD_VidWriteString("LED:")	;

	LCD_GoToXY(1,0);
	LCD_VidWriteString("LIGHT=");
	LCD_VidWriteNumber(LIGHT);
	LCD_GoToXY(1,9);
	LCD_VidWriteData('%');
	if(LIGHT<25)
	{
		DIO_VidSetPinValue(PORTB,PIN5,HIGH);
		LCD_GoToXY(0,11);
		LCD_VidWriteString("ON")	;
	}
	else
	{
		DIO_VidSetPinValue(PORTB,PIN5,LOW);
		LCD_GoToXY(0,11);
		LCD_VidWriteString("OFF")	;

	}
	_delay_ms(500);
	LCD_CLEAR(0,11,15);
	LCD_CLEAR(1,6,9);


}*/
void DC_MOTOR (void)
{
	LCD_GoToXY(0,0);
	LCD_VidWriteString("DC_MOTOR");
	LCD_GoToXY(1,0);
	LCD_VidWriteString("Duty_Cycle=");
	DATA=USART_Receive();                         //Receive data from HC-o5
	if(DATA!=13 && DATA!=10)                       //to avoid common wrong
		{



			LCD_GoToXY(1,0);
			LCD_VidWriteString("Duty_Cycle=");
			LCD_VidWriteNumber(DATA*10);                  //To show the receive data on LCD
			LCD_GoToXY(1,13);
			LCD_VidWriteString("%");
			Set_Duty_Cycle(DATA);



		}
}
