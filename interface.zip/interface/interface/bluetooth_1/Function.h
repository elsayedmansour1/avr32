/*
 * Function.h
 *
 *  Created on: Jul 14, 2020
 *      Author: elsay
 */

void ID(void);
void PASSWORD(void);
void StartScreen(void);
u8 Controll(void);
u8 Controll2(void);
void elsayed(u8 choose);
//void LM_35_SENSOR (u8 LOC_u8SelectChannel);
void LDR_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus);
void DC_MOTOR (void);
