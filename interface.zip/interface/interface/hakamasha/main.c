/*
 * main.c
 *
 *  Created on: Jun 9, 2020
 *      Author: elsay
 */
#include "STD_TYPES.h"
#include "LCD_Interface.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include<avr/delay.h>
void main(void)
{
u8  ball_down     [8]= { 0x00, 0x00,  0x00,  0x00,  0x0E,  0x1F,  0x1F,  0x0E         };
u8  ball_up     [10]= {  0x0E,  0x1F,  0x1F,  0x0E,  0x00,  0x00, 0x00, 0x00};
u8  face     [8]= {0x0E,  0x11,  0x1B,  0x11,  0x1F,  0x11,  0x0E,  0x04         };
u8  body     [8]=   { 0x1F,  0x15,  0x15,  0x04,  0x0A,  0x0A,  0x0A,  0x1B      };
u8  gool_up  [8]=  {0x10,  0x18,  0x14,  0x12,  0x11,  0x11,  0x11,  0x11        };
u8  gool_down[8]=   {0x11,  0x11,  0x11,  0x11,  0x09,  0x05,  0x03,  0x01       };
u8  body_2   [8]=  {0x04,  0x0C,  0x0C,  0x14,  0x04,  0x0A,  0x0A,  0x14        };
u8  face_2   [8]=  {0x1F,  0x1F,  0x11,  0x13,  0x11,  0x17,  0x11,  0x0E        };
u8  body_3   [8]=  {  0x04,  0x0C,  0x1C,  0x14,  0x04,  0x0A,  0x0A,  0x0B       };
u8  body_4   [8]= { 0x15,  0x15,  0x1F,  0x04,  0x0E,  0x0A,  0x0A,  0x1B};
	LCD_VidInit();
	LCD_VidWriteString(" START THE GAME");
	_delay_ms(1000);
    LCD_VidWriteCommend(0B00000001);//clear display


	while(1)
{

	    /*access to CGRAM*/
	LCD_VidWriteCommend(64);
		/*for face*/
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(face[i]);
	}
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(body  [i]);
	}
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(ball_down  [i]);
	}
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(gool_up   [i]);
	}
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(gool_down [i]);
	}
	GoToXY(0,0);
	LCD_VidWriteData(0);
	/*for body*/
	GoToXY(1,0);
	LCD_VidWriteData(1);

	GoToXY(1,1);
		LCD_VidWriteData(2);

	GoToXY(0,15);
	LCD_VidWriteData(3);

	GoToXY(1,15);
	LCD_VidWriteData(4);
	_delay_ms(400);
	/////////////////////////////////////////////////////////////////////////////////////////////
	LCD_VidWriteCommend(64);
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(face_2 [i]);
		}
	for(u8 i=0;i<8;i++)
			{
			LCD_VidWriteData(body_2 [i]);
			}
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(ball_down  [i]);
		}
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(gool_up   [i]);
		}
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(gool_down [i]);
		}
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(body_3 [i]);
		}
	for(u8 i=0;i<8;i++)
		{
		LCD_VidWriteData(ball_up [i]);
		}

	for(u8 i=0;i<10;i++)
	{
		GoToXY(0,i);
		LCD_VidWriteData(0);//face_2

		GoToXY(1,i);
		LCD_VidWriteData(1);//body_2

		GoToXY(1,1+i);
		LCD_VidWriteData(2);//ball
		_delay_ms(300);
	    LCD_VidWriteCommend(0B00000001);//clear display

		GoToXY(0,15);
		LCD_VidWriteData(3);//gool_up

		GoToXY(1,15);
		LCD_VidWriteData(4);//gool_down

	}
//////////////////////////////////////////////////////////////////////////////////////////////////

	    GoToXY(0,10);
		LCD_VidWriteData(0);//face_2

		GoToXY(1,10);
		LCD_VidWriteData(5);//body_2

		GoToXY(1,14);
		LCD_VidWriteData(6);//ball_up
		_delay_ms(400);
	    LCD_VidWriteCommend(0B00000001);//clear display
		GoToXY(0,15);
		LCD_VidWriteData(3);//gool_up

		GoToXY(1,15);
		LCD_VidWriteData(4);//gool_down
		_delay_ms(400);
	 LCD_VidWriteCommend(0B00000001);//clear display
	LCD_VidWriteString("GOOOOOOOOOOOOOL");
	_delay_ms(400);
	LCD_VidWriteCommend(0B00000001);//clear display
    /*access to CGRAM*/
LCD_VidWriteCommend(64);
	/*for face*/
for(u8 i=0;i<8;i++)
{
LCD_VidWriteData(face[i]);
}
for(u8 i=0;i<8;i++)
{
LCD_VidWriteData(body_4  [i]);
}
GoToXY(0,0);
LCD_VidWriteData(0);
LCD_VidWriteString(" HAMOKSHA WINS");
/*for body*/
GoToXY(1,0);
LCD_VidWriteData(1);


	_delay_ms(2000);
	LCD_VidWriteCommend(0B00000001);//clear display
	}
}

