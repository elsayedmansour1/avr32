
#include<avr/io.h>


void main (void)
{
	DDRA=0b00000001;

	PORTA=0b00000010;
	while(1)
	{
		if(PINA ==0b00000010)
			{
				PORTA=0b00000001;


			}
			else if(PINA ==0b00000000)
				{
				PORTA=0b00000000;
				}
	}









}

