/*
 * main.c
 *
 *  Created on: Jun 15, 2020
 *      Author: elsay
 */

#include "STD_TYPES.h"
#include "LCD_Interface.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include<avr/delay.h>
#include "Keypad_Interface.h"
#define UP 1
#define DOWN 2
void main(void)
{
	KEYPAD_VidInit();
	u8 on_off=0;
	u8 controll=0;
	u8 enter=0;
	u8 choose=0;
	u8 page=0;
	DIO_VidSetPinDirection(PORTC,PIN0,OUTPUT);
	DIO_VidSetPinDirection(PORTC,PIN1,OUTPUT);
	u8 empty[]={0,0,0,0,0,0,0,0};
	while(1)
	{
		on_off=KEYPAD_on_off();
		if(on_off!=0)
			{
				if(on_off==1)
				{
					LCD_VidInit();
					GoToXY(0,0);
					LCD_VidWriteString("1-DC Motor");
					GoToXY(1,0);
					LCD_VidWriteString("2-Stepper");
					break;
				}

			}
	}
	while(1)
	{

		controll=KEYPAD_Controll();
		enter=KEYPAD_Enter();

		if(controll!=0)
		{
			if(controll==1)                  //up for any page;
			{

				constant(empty,0,1,15,0);   //to remove < from row 2;
				GoToXY(0,15);
				LCD_VidWriteData('<');

				choose=UP;                   //up for any page;

			}
			else if(controll==2)           //down for any page;
			{

				constant(empty,0,0,15,0);  //to remove < from row 1;
				GoToXY(1,15);
				LCD_VidWriteData('<');

				choose=DOWN;                 //down for any page;
			}
		}
		else if(enter!=0)
		{
			if(enter==1)
			{  page++;
			//enter=0;
				LCD_VidWriteCommend(1);
			}
		}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////

		if(choose==UP&&page==1)                //you choose up in page one
		{

			GoToXY(0,0);
			LCD_VidWriteString("1-clockwise");

			GoToXY(1,0);
			LCD_VidWriteString("2-unticlockwise");

		}
		else if(choose==DOWN&&page==1)           //you choose down in page one
		{
			GoToXY(0,0);
			LCD_VidWriteString("1-clockwise");

			GoToXY(1,0);
			LCD_VidWriteString("2-unticlockwise");
		}
		else if(choose==UP&&page==2)            //you choose up in page two
		{
			GoToXY(0,5);
			LCD_VidWriteString(" CLOCKWISE");
			DIO_VidSetPinValue(PORTC,PIN1,0);
			DIO_VidSetPinValue(PORTC,PIN0,1);
		}
		else if(choose==DOWN&&page==2)                //you choose down in page two
		{
			GoToXY(0,0);
			LCD_VidWriteString("ANTICLOCKWISE");
			DIO_VidSetPinValue(PORTC,PIN0,0);
			DIO_VidSetPinValue(PORTC,PIN1,1);
		}

	}//close Bracket for endless while loop;

} //close Bracket for main;
