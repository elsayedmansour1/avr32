#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"



void KEYPAD_VidInit(void)
{
	DIO_VidSetPortDirection ( PORTA,0B00001111);
	DIO_VidSetPortValue	( PORTA, 0B11111111);
}


u8 KEYPAD_on_off(void)
{
	u8 col;
	u8 keypad_out=0;
	u8 on_off[]={1,2};
	for(col=0;col<2;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
		if(DIO_vidGitPinValue(PORTA,4)==0)
		{

			keypad_out=on_off[col];
			while(DIO_vidGitPinValue(PORTA,4)==0)
			{

			}
			_delay_ms(50);
		}
		DIO_VidSetPinValue	( PORTA, col, 1);

	}
	return keypad_out;
}
u8 KEYPAD_Controll(void)
{
	u8 col;
	u8 keypad_out=0;
	u8 on_off[]={1,2,3};
	for(col=0;col<3;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
		if(DIO_vidGitPinValue(PORTA,5)==0)
		{

			keypad_out=on_off[col];
			while(DIO_vidGitPinValue(PORTA,5)==0)
			{

			}
			_delay_ms(50);
		}
		DIO_VidSetPinValue	( PORTA, col, 1);

	}
	return keypad_out;
}
u8 KEYPAD_Enter(void)
{
	u8 col;
	u8 keypad_out=0;


		DIO_VidSetPinValue	( PORTA, 1, 0);
		if(DIO_vidGitPinValue(PORTA,7)==0)
		{

			keypad_out=1;
			while(DIO_vidGitPinValue(PORTA,7)==0)
			{

			}
			_delay_ms(50);
		}
		DIO_VidSetPinValue	( PORTA, 1, 1);


	return keypad_out;
}
