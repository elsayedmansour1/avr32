#ifndef _KEYPAD_INTERFACE_H_
#define _KEYPAD_INTERFACE_H_






void KEYPAD_VidInit(void);

u8 GET_PressedKey(void);

u8 GET_PressedKeyNew(void);

u8 KEYPAD_VidCal(u8 x);

u8 KEYPAD_on_off(void);

u8 KEYPAD_Controll(void);

u8 KEYPAD_Enter(void);













#endif
