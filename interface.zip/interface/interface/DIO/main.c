#include<avr/io.h>
#include<avr/delay.h>
int main()
{
	DDRA=0B11111111;
	int x;
	while(1)
	{
		for(x=0;x<8;x++)
		{
			PORTA=0B10000000>>x;

					_delay_ms(100);
		}
		for(x=0;x<7;x++)
				{
					PORTA=0B00000001<<x;

							_delay_ms(100);
				}
	}
}
