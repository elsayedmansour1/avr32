#include "STD_TYPES.h"
#include "LCD_Register.h"
#include "BIT_Math.h"
#include "avr/delay.h"
#include"DIO_Interface.h"




//0B00111000;
//0B00001100;








void LCD_VidInit(void)
{               _delay_ms(50);
  /*set direction*/
	DIO_VidSetPortDirection(PORTD,0XFF);
	DIO_VidSetPortDirection(PORTB,0B00000111);
	
	LCD_VidWriteCommend(0B00111000);//function set
	_delay_ms(1);
	LCD_VidWriteCommend(0B00001100);//screen on
          _delay_ms(1);
	LCD_VidWriteCommend(0B00000001);//clear display
          _delay_ms(2);
	LCD_VidWriteCommend(0B00000110);//Mode Set
	LCD_VidWriteCommend(0B00000010);//Return Home
	LCD_VidWriteCommend(0B00000001);
	LCD_VidWriteCommend(0B00000001);
}
void LCD_VidWriteCommend(u8 LCD_u8Commend)
{
	DIO_VidSetPinValue(PORTB,PIN0,0);  //RS=0
	DIO_VidSetPinValue(PORTB,PIN1,0);  //RW=0
	DIO_VidSetPortValue(PORTD,LCD_u8Commend); //write commend
	
	DIO_VidSetPinValue(PORTB,PIN2,1);  //EN=1
	_delay_ms(1);
	DIO_VidSetPinValue(PORTB,PIN2,0);  //EN=0
	
	_delay_ms(1);     //wait lcd to write letter
	
}
void LCD_VidWriteData(u8 LCD_u8Data)
{
	DIO_VidSetPinValue(PORTB,PIN0,1);  //RS=0
	DIO_VidSetPinValue(PORTB,PIN1,0);  //RW=0
	DIO_VidSetPortValue(PORTD,LCD_u8Data); //write commend
	
	DIO_VidSetPinValue(PORTB,PIN2,1);  //EN=1
	_delay_ms(1);
	DIO_VidSetPinValue(PORTB,PIN2,0);  //EN=0
	
	_delay_ms(1);     //wait lcd to write letter
}
void LCD_VidWriteString(u8 *ptr)
{
	for(u8 i=0;i<100;i++)
	{
		if(ptr[i]=='\0')
		    {
		    	break;
		    }
	LCD_VidWriteData(ptr[i]);

	}
	
}

void LCD_VidSetMove(u8 *ptr,u8 max)
{
	u8 m=1;
	u8 i;
	for(u8 z=0;z<max;z++)
	{
		for(u8 x=0;x<40;x++)
		{
			LCD_VidWriteCommend(0B00000001);//clear display
			for(i=0;i<m;i++)
			{

				LCD_VidWriteCommend(0B00011100);//cursor
			}
			m++;

			LCD_VidWriteString(ptr);
			_delay_ms(400);
		}
	}




}
void LCD_VidWriteNumber(u32 x)
{ x=x+1;
u32 reverse=0;
u32 y;
	while(x>0)
	{

	reverse=reverse*10+x%10;
	x=x/10;
	}
	while(reverse>0 )
	{

	if(reverse<10 && reverse>0)
	{
		LCD_VidWriteData(reverse-1+48);

		reverse=0;
	}
	else
	{
		y=reverse%10;
		LCD_VidWriteData(y+48);
		reverse=reverse/10;
	}

	}
}
void LCD_GoToXY(u8 row,u8 col)
{
	if(row==0)
	{
		LCD_VidWriteCommend(128+col);
	}
	else if (row==1)
	{
		LCD_VidWriteCommend(192+col);
	}
}
void LCD_CONSTANT(u8 *Arr,u8 Adress,u8 Row,u8 Col,u8 Data)
{
//	LCD_VidWriteCommend(1);
	LCD_VidWriteCommend(Adress+64);
		/*for face*/
for(u8 i=0;i<8;i++)
	{
	LCD_VidWriteData(Arr[i]);
	}

LCD_GoToXY(Row,Col);
LCD_VidWriteData(Data);
}
void CLEAR(u8 Row,u8 start,u8 end)
{
	u8 empty[8]={0,0,0,0,0,0,0,0};
	while(1)
	{
		LCD_CONSTANT(empty,0,Row,start,0);
		  start++;
		  if(start==end)
		  {
			  break;
		  }
	}


}

