/*
 * main.c
 *
 *  Created on: Jul 7, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<util/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
void main(void)
{
	u8 CULOM[] = {0x10,	 0x10,	 0x10,		0x10,	 0x10,	0x10,	0x10,	0x10	};
	u8 CULOM0[] = {0x1F,   0x10,   0x10,	  0x10,	  0x10,   0x10,   0x10,   0x10  };
	u8 CULOM1[] = {	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x10,	  0x1F	};
	u8 ROW[]   = {0x1F,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00	};
	u8 ROW0[]   = {0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x00,	  0x1F	};
	LCD_VidInit();
	u8 x=0;
	for(u8 i=0;i<15;i++)
	{
		LCD_CONSTANT(CULOM ,0 ,1,x+i,0);
		LCD_CONSTANT(CULOM0,8 ,0,x+i,1);
		x++;
		LCD_CONSTANT(ROW   ,16,0,x+i,2);
		x++;
		LCD_CONSTANT(CULOM ,0 ,0,x+i,0);
		LCD_CONSTANT(CULOM1,24,1,x+i,3);
		x++;
		LCD_CONSTANT(ROW0  ,32,1,x+i,4);
	}
	/*LCD_CONSTANT(CULOM ,0 ,1,0,0);
	LCD_CONSTANT(CULOM0,8 ,0,0,1);
	LCD_CONSTANT(ROW   ,16,0,1,2);
	LCD_CONSTANT(CULOM ,0 ,0,2,0);
	LCD_CONSTANT(CULOM1,24,1,2,3);*/
}
