#include"STD_TYPES.h"
#include"BIT_Math.h"
#include"ADC_Register.h"
#include"ADC_Interface.h"
#include"DIO_Interface.h"
#include<avr/delay.h>
#include"LCD_Interface.h"

void ADC_INIT(void)
{
	/* CLR_BIT(ADMUX, REFS1);
	 SET_BIT(ADMUX, REFS0);
	 CLR_BIT(ADMUX, ADLAR);
	 SET_BIT(ADCSRA, ADPS0);
	 SET_BIT(ADCSRA, ADPS1);
	 CLR_BIT(ADCSRA, ADPS0);
	 CLR_BIT(ADCSRA, ADATE);
	 SET_BIT(ADCSRA, ADEN);*/
	//for interrupt
	     CLR_BIT(ADMUX, REFS1);
		 SET_BIT(ADMUX, REFS0);
		 CLR_BIT(ADMUX, ADLAR);
		 SET_BIT(ADCSRA, ADPS0);
		 SET_BIT(ADCSRA, ADPS1);
		 CLR_BIT(ADCSRA, ADPS0);
		 CLR_BIT(ADCSRA, ADATE);
		 SET_BIT(ADCSRA, ADEN);
		 SET_BIT(ADCSRA, ADIE);
}
u16 ADC_GET_RESULT(u8 LOC_U8Channal)
{   // DIO_VidSetPinDirection(PORTC,PIN0,OUTPUT);
	ADMUX=ADMUX|LOC_U8Channal;
	 SET_BIT(ADCSRA, ADSC);
	/* while(GET_BIT(ADCSRA,ADIF)==0)
	 {

	 }

	 SET_BIT(ADCSRA, ADIF);*/

	 return ADC;
}
void __vector_16(void)__attribute__((signal));
void __vector_16(void)
{

	u16 output;
	output=(ADC*5000UL)/1024;
	GoToXY(0,0);
	LCD_VidWriteString(" the value is:");
	GoToXY(1,5);
	LCD_VidWriteNumber(output);

	if(output>1500 && output<3000)
	{
		DIO_VidSetPinValue(PORTC,PIN0,1);
	}
	else
	{
		DIO_VidSetPinValue(PORTC,PIN0,0);
	}
	_delay_ms(500);
	CLEAR(1,5,9);
}
