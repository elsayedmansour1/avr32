#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "Global_Interrupt_Enable_Interface.h"
#include "Global_Interrupt_Enable_Register.h"
#include "BIT_Math.h"







void SREG_VidEnable(void)
{
	SET_BIT(SREG, 7);
}
void SREG_VidDisable(void)
{
	CLR_BIT(SREG, 7);
}
