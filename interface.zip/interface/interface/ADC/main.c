/*
 * main.c
 *
 *  Created on: Jun 20, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"ADC_Interface.h"
#include"LCD_Interface.h"
void main(void)
{
	DIO_VidSetPinDirection(PORTC,PIN0,OUTPUT);

	ADC_INIT();
	LCD_VidInit();
	SREG_VidEnable();
	LCD_VidWriteString("Wellcome Elsayed");
	_delay_ms(700);
	LCD_VidWriteCommend(0B00000001);//clear display
	u16 Value=0;
	u16 output=0;
	while(1)
	{

		Value=ADC_GET_RESULT(ADC0);
		output=(Value*5000UL)/1024;
		GoToXY(0,0);
		LCD_VidWriteString(" the value is:");
		GoToXY(1,5);
		LCD_VidWriteNumber(output);
		if(output>1500 && output<3000)
		{
			DIO_VidSetPinValue(PORTC,PIN0,1);
		}
		else
		{
			DIO_VidSetPinValue(PORTC,PIN0,0);
		}
	//	LCD_VidWriteCommend(0B00000001);//clear display
		_delay_ms(500);
		CLEAR(1,5,9);
	}

}
