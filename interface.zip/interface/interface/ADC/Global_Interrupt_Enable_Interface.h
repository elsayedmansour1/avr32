#ifndef _Global_Interrupt_Enable_INTERFACE_H_
#define _Global_Interrupt_Enable_INTERFACE_H_





void SREG_VidEnable(void);
void SREG_VidDisable(void);



















#endif