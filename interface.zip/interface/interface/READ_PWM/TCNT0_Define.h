#ifndef _TCNT0_DEFINE_H_
#define _TCNT0_DEFINE_H_

                /*TCCR0 REGISTER*/
#define FOC0      7 //force output compare

#define WGM00     6 //waveform generation mode 00
#define WGM01     3 //waveform generation mode 01

#define COM01     5 //compare output mode 1
#define COM00     4 //compare output mode 0

#define CS02      2 //clock selection 02
#define CS01      1 //clock selection 01
#define CS00      0 //clock selection 00
/****************************************************************************************************************/
/****************************************************************************************************************/
            /*TIMSK REGISTER*/
#define OCIE2     7  //output compare Interrupt Enable in TIMER 2
#define TOIE2     6  //TIMER 2 overflow Interrupt Enable
#define TICIE1    5  //Input Capture Interrupt Enable in TIMER 1
#define OCIE1A    4  //output compare A Interrupt Enable in TIMER 1
#define OCIE1B    3  //output compare B Interrupt Enable in TIMER 1
#define TOIE1     2  //TIMER 1 overflow Interrupt Enable
#define OCIE0     1  //output compare Interrupt Enable in TIMER 0
#define TOIE0     0  //TIMER 0 overflow Interrupt Enable

/****************************************************************************************************************/
/****************************************************************************************************************/
             /*TCCR2*/
#define FOC2     7   //force output compare
#define WGM20    6   //waveform generation mode 20
#define COM21    5   //compare output mode 1
#define COM20    4   //compare output mode 0
#define WGM21    3   //waveform generation mode 21
#define CS22     2   //clock selection 22
#define CS21     1   //clock selection 21
#define CS20     0   //clock selection 20

/****************************************************************************************************************/
/****************************************************************************************************************/


     /*ALL DEFINITIONS YOU WILL NEED IN TIMNER2 */
                  /*START_TIMER2{*/
                /*MODES*/
#define Normal_0      	   CLR_BIT(TCCR0, WGM01);\
	                       CLR_BIT(TCCR0, WGM00);

#define PWM_Phase_Correct_0  CLR_BIT(TCCR0, WGM01);\
	                       SET_BIT(TCCR0, WGM00);

#define CTC_Mode_0           SET_BIT(TCCR0, WGM01);\
	                       CLR_BIT(TCCR0, WGM00);

#define Fast_PWM_0         SET_BIT(TCCR0, WGM01);\
		                   SET_BIT(TCCR0, WGM00);

#define Normal_Timer0_Mode                   0
#define PWM_Phase_Correct_Timer0_Mode        1
#define CTC_Timer0_Mode       				2
#define Fast_PWM_Timer0_Mode	 				3



/********************************/
#define Timer0_Mode  Fast_PWM_Timer0_Mode
/********************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

    /*Compare Output Mode, non-PWM Mode*/
#define Non_PWM_Normal_OC0_disconnected_0         CLR_BIT(TCCR0,COM01);\
	                                    CLR_BIT(TCCR0,COM00);

#define Toggle_OC0_on_compare_match_0     CLR_BIT(TCCR0,COM01);\
										SET_BIT(TCCR0,COM00);

#define Clear_OC0_on_compare_match_0      SET_BIT(TCCR0,COM01);\
										CLR_BIT(TCCR0,COM00);

#define Set_OC0_on_compare_match_0        SET_BIT(TCCR0,COM01);\
										SET_BIT(TCCR0,COM00);
#define OC0_disconnected_Timer0     0
#define Toggle_OC0_Timer0           1
#define Clear_OC0_Timer0            2
#define Set_OC0_Timer0              3





/*********************************************/
#define Compare_Output_Mode OC0_disconnected_Timer0
/*********************************************/



/****************************************************************************************************************/
/****************************************************************************************************************/
             /*Compare Output Mode, Fast PWM Mode*/
#define Normal_OC0_disconnected_0        		          CLR_BIT(TCCR0,COM01);\
	                                                  CLR_BIT(TCCR0,COM00);

#define Reserved_0                                      CLR_BIT(TCCR0,COM01);\
	                                                  SET_BIT(TCCR0,COM00);

#define NonInverted_Mode_0     						  SET_BIT(TCCR0,COM01);\
	                                                  CLR_BIT(TCCR0,COM00);

#define Inverted_Mode_0       						  SET_BIT(TCCR0,COM01);\
	                                                  SET_BIT(TCCR0,COM00);

#define Normal_Mode_Timer0	                               0
#define reserved_mode_Timer0	                           1
#define NonInverted_Mode_Timer0	     			           2
#define Inverted_Mode_Timer0	        		           3





/*************************************/

#define Fast_PWM_MODE  NonInverted_Mode_Timer0

/************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

                    /*Clock Select*/
#define Timer_Counter stopped_0          		 CLR_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
					                         CLR_BIT(TCCR0,CS00);

#define No_prescaling_0                 	   	 CLR_BIT(TCCR0,CS02);\
											 CLR_BIT(TCCR0,CS01);\
											 SET_BIT(TCCR0,CS00);

#define prescaler_clk_8_0 	          		 CLR_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
	                                         CLR_BIT(TCCR0,CS00);

#define prescaler_clk_64_0    			 	 CLR_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
	                                         SET_BIT(TCCR0,CS00);

#define prescaler_clk_256_0   				 SET_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
	                                         CLR_BIT(TCCR0,CS00);

#define prescaler_clk_1024_0 	              	 SET_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
					                         SET_BIT(TCCR0,CS00);

#define External_Clock_on_falling_edge_0 	     SET_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
					                         CLR_BIT(TCCR0,CS00);

#define External_Clock_on_rising_edge_0		 SET_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
					                         SET_BIT(TCCR0,CS00);

#define 	Timer0_prescaler_0                   0
#define 	Timer0_prescaler_1                   1
#define 	Timer0_prescaler_8                   8
#define 	Timer0_prescaler_64                  64
#define 	Timer0_prescaler_256                 256
#define 	Timer0_prescaler_1024                1024
#define 	Timer0_External_falling_edge         2
#define     Timer0_External_rising_edge	      3




/****************************************/

#define clock_select  Timer0_prescaler_256

/****************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/
                    /*INTERRUPT MODE*/
#define Compare_Match_Interrupt_Enable_0        SET_BIT(TIMSK,OCIE0);\
                                              CLR_BIT(TIMSK,TOIE0);

#define Overflow_Interrupt_Enable_0             CLR_BIT(TIMSK,OCIE0);\
                                              SET_BIT(TIMSK,TOIE0);

#define COM_Interrupt_Enable_Timer0    0
#define OVF_Interrupt_Enable_Timer0    1
/*********************************************/

#define INTERRUPT_MODE  CM_Interrupt_Enable_Timer0

/*********************************************/
                     /*}END_TIMER0*/
/************************************************************************************************************************************/
/************************************************************************************************************************************/
     /*ALL DEFINITIONS YOU WILL NEED IN TIMNER2 */
                  /*START_TIMER2{*/
                /*MODES*/
#define Normal_2      	     CLR_BIT(TCCR2, WGM21);\
	                         CLR_BIT(TCCR2, WGM20);

#define PWM_Phase_Correct_2  CLR_BIT(TCCR2, WGM21);\
	                         SET_BIT(TCCR2, WGM20);

#define CTC_Mode_2           SET_BIT(TCCR2, WGM21);\
	                         CLR_BIT(TCCR2, WGM20);

#define Fast_PWM_2           SET_BIT(TCCR2, WGM21);\
		                     SET_BIT(TCCR2, WGM20);

#define Normal_Timer2_Mode                   0
#define PWM_Phase_Correct_Timer2_Mode        1
#define CTC_Timer2_Mode       				2
#define Fast_PWM_Timer2_Mode	 				3



/********************************/
#define Timer2_Mode  Normal_Timer2_Mode
/********************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

    /*Compare Output Mode, non-PWM Mode*/
#define Non_PWM_Normal_OC0_disconnected_2       CLR_BIT(TCCR2,COM21);\
	                                    CLR_BIT(TCCR2,COM20);

#define Toggle_OC0_on_compare_match_2   CLR_BIT(TCCR2,COM21);\
										SET_BIT(TCCR2,COM20);

#define Clear_OC0_on_compare_match_2    SET_BIT(TCCR2,COM21);\
										CLR_BIT(TCCR2,COM20);

#define Set_OC0_on_compare_match_2      SET_BIT(TCCR2,COM21);\
										SET_BIT(TCCR2,COM20);
#define OC0_disconnected_Timer2     0
#define Toggle_OC0_Timer2           1
#define Clear_OC0_Timer2            2
#define Set_OC0_Timer2              3





/*********************************************/
#define Compare_Output_Mode OC0_disconnected_Timer2
/*********************************************/



/****************************************************************************************************************/
/****************************************************************************************************************/
             /*Compare Output Mode, Fast PWM Mode*/
#define Normal_OC0_disconnected_2        		      CLR_BIT(TCCR2,COM21);\
	                                                  CLR_BIT(TCCR2,COM20);

#define Reserved_2                                    CLR_BIT(TCCR2,COM21);\
	                                                  SET_BIT(TCCR2,COM20);

#define NonInverted_Mode_2     						  SET_BIT(TCCR2,COM21);\
	                                                  CLR_BIT(TCCR2,COM20);

#define Inverted_Mode_2       						  SET_BIT(TCCR2,COM21);\
	                                                  SET_BIT(TCCR2,COM20);

#define Normal_Mode_Timer2	                               0
#define reserved_mode_Timer2	                           1
#define NonInverted_Mode_Timer2	     			           2
#define Inverted_Mode_Timer2	        		           3





/*************************************/

#define Fast_PWM_MODE  NonInverted_Mode_Timer2

/************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

                    /*Clock Select*/
#define Timer_Counter stopped_2              CLR_BIT(TCCR2,CS22);\
	                                         CLR_BIT(TCCR2,CS21);\
					                         CLR_BIT(TCCR2,CS20);

#define No_prescaling_2                 	 CLR_BIT(TCCR2,CS22);\
											 CLR_BIT(TCCR2,CS21);\
											 SET_BIT(TCCR2,CS20);

#define prescaler_clk_8_2 	          		 CLR_BIT(TCCR2,CS22);\
	                                         SET_BIT(TCCR2,CS21);\
	                                         CLR_BIT(TCCR2,CS20);

#define prescaler_clk_64_2    			 	 CLR_BIT(TCCR2,CS22);\
	                                         SET_BIT(TCCR2,CS21);\
	                                         SET_BIT(TCCR2,CS20);

#define prescaler_clk_256_2   				 SET_BIT(TCCR2,CS22);\
	                                         CLR_BIT(TCCR2,CS21);\
	                                         CLR_BIT(TCCR2,CS20);

#define prescaler_clk_1024_2	             SET_BIT(TCCR2,CS22);\
	                                         CLR_BIT(TCCR2,CS21);\
					                         SET_BIT(TCCR2,CS20);

#define External_Clock_on_falling_edge_2 	 SET_BIT(TCCR2,CS22);\
	                                         SET_BIT(TCCR2,CS21);\
					                         CLR_BIT(TCCR2,CS20);

#define External_Clock_on_rising_edge_2		 SET_BIT(TCCR2,CS22);\
	                                         SET_BIT(TCCR2,CS21);\
					                         SET_BIT(TCCR2,CS20);
#define 	Timer2_prescaler_0                   0
#define 	Timer2_prescaler_1                   1
#define 	Timer2_prescaler_8                   8
#define 	Timer2_prescaler_64                  64
#define 	Timer2_prescaler_256                 256
#define 	Timer2_prescaler_1024                1024
#define 	Timer2_External_falling_edge         2
#define     Timer2_External_rising_edge	      3




/****************************************/

#define clock_select  Timer2_prescaler_256

/****************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/
                    /*INTERRUPT MODE*/
#define Compare_Match_Interrupt_Enable_2      SET_BIT(TIMSK,OCIE2);\
                                              CLR_BIT(TIMSK,TOIE2);

#define Overflow_Interrupt_Enable_2           CLR_BIT(TIMSK,OCIE2);\
                                              SET_BIT(TIMSK,TOIE2);

#define COM_Interrupt_Enable_Timer2    0
#define OVF_Interrupt_Enable_Timer2    1
/**********************************************/

#define INTERRUPT_MODE  OVF_Interrupt_Enable_Timer2

/*********************************************/
                     /*}END_TIMER2*/
#endif
