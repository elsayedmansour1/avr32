#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "TCNT0_Register.h"
#include "TCNT0_Interface.h"
#include"TCNT0_Define.h"





static void (*GPFunc)(void)=NULL;
void TCNT2_SetCallBack(void (*LocalPFunc)(void))
{
	GPFunc=LocalPFunc;
}
ISR_TMR(COM)
{
	if(GPFunc!=NULL)
	{
		GPFunc();
	}
}




void TCNT0_INIT(void)
{
#if Timer0_Mode==Normal_Timer0_Mode
	TCNT0=0;                       //YOU SHOULD CHANGE THIS BIT
	Normal_0;
	prescaler_clk_256_0;
	Non_PWM_Normal_OC0_disconnected_0;
	Overflow_Interrupt_Enable_0;
#elif Timer0_Mode==CTC_Timer0_Mode
	OCR0=256;                     //YOU SHOULD CHANGE THIS BIT
	CTC_Mode_0;
	prescaler_clk_256_0;
	Non_PWM_Normal_OC0_disconnected_0;
	Compare_Match_Interrupt_Enable_0;
#elif Timer0_Mode==Fast_PWM_Timer0_Mode
	Fast_PWM_0;
	NonInverted_Mode_0;
	prescaler_clk_256_0;
#elif Timer0_Mode==PWM_Phase_Correct_Timer0_Mode
	PWM_Phase_Correct_0;
	prescaler_clk_256_0;

#else
#error "WRONG CHOOSE"
#endif

}
void Set_Duty_Cycle(f32 Value)
{
	//Value=Value/100;
	//OCR0=Value*255;
	OCR0=Value;
}

void TCNT2_INIT(void)
{
#if Timer2_Mode==Normal_Timer2_Mode
	                             //YOU SHOULD CHANGE THIS BIT
	Normal_2;
	prescaler_clk_256_2;
	Non_PWM_Normal_OC0_disconnected_2;
	Overflow_Interrupt_Enable_2;
#elif Timer2_Mode==CTC_Timer2_Mode
	OCR2=256;                     //YOU SHOULD CHANGE THIS BIT
	CTC_Mode_2;
	prescaler_clk_256_2;
	Non_PWM_Normal_OC0_disconnected_2;
	Compare_Match_Interrupt_Enable_2;
#elif Timer2_Mode==Fast_PWM_Timer2_Mode
	Fast_PWM_2;
	NonInverted_Mode_2;
	prescaler_clk_256_2;
#elif Timer2_Mode==PWM_Phase_Correct_Timer2_Mode
	PWM_Phase_Correct_2;
	prescaler_clk_256_2;

#else
#error "WRONG CHOOSE"

#endif
}



