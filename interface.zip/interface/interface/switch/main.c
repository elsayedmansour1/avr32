#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO_Interface.h"

#include <util/delay.h>

void main (void)
{

	DIO_VidSetPortDirection	( PORTA ,0XFF);

	while (1)
	{
		DIO_VidSetPortValue	( PORTA , 0XFF);
		_delay_ms(500);
		DIO_VidSetPortValue	( PORTA , 0XFF);
		_delay_ms(100);
	}

}
