#ifndef _UART_INTERFACE_H_
#define _UART_INTERFACE_H_

#define ISR_USART_RX()  void __vector_13(void)__attribute__((signal));\
	                     void __vector_13(void)
#define ISR_USART_UDRE()  void __vector_14(void)__attribute__((signal));\
	                     void __vector_14(void)

void RX_SetCallBack(void (*LocalPFunc)(void));
void UDRE_SetCallBack(void (*LocalPFunc1)(void));

void UART_INIT(void);
void UART_Transmit (u16 SEND);
u8 UART_Recive (void);
void RX_Enterrupt_Enable(void);
void RX_Enterrupt_Disable(void);
void SEND_Enterrupt_Enable(void);



















#endif
