/*
 * main.c
 *
 *  Created on: Aug 8, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include "util/delay.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"

void main(void)
{
	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX

	LCD_VidInit();								//LCD Initialization
	UART_INIT();								//USART Initialization

	u8 data=0;
	LCD_VidWriteString("you are ugly");
	_delay_ms(1000);
	while(1)
	{
		data=UART_Recive();
		LCD_VidWriteData(data);
		_delay_ms(1000);

	}
}
