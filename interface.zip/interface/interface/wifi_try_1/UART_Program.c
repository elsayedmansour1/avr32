#include "STD_TYPES.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"UART_Interface.h"
//#include"ADC_Register.h"
//#include"ADC_Interface.h"

/*GLOBAL POINTER TO FUNCTION*/

static void (*GPFunc)(void)=NULL;
void RX_SetCallBack(void (*LocalPFunc)(void))
{
	GPFunc=LocalPFunc;
}

ISR_USART_RX()
{
	if(GPFunc!=NULL)
	{
		GPFunc();
	}
}

static void (*GPFunc1)(void)=NULL;
void UDRE_SetCallBack(void (*LocalPFunc1)(void))
{
	GPFunc1=LocalPFunc1;
}

ISR_USART_UDRE()
{
	if(GPFunc!=NULL)
	{
		GPFunc1();
	}
}

u8 Temporary_REG=0;
void UART_INIT(void)
{
     /*enable*/
	Receiver_Enable;
	Transmitter_Enable;
	SET_BIT( USCRA , U2X);  //double speed
	/*Character Size*/
	//Eight_Bit;
	/*Register Select*/
	//SET_BIT( Temporary_REG , URSEL );

	USCRC=0b10000110;
	
	UBRRH=0;
	UBRRL=3;



}
void UART_Transmit (u16 SEND)
{


	while(GET_BIT(USCRA,UDRE)==0)
	{

	}
	UDR=SEND;

}
u8 UART_Recive (void)
{
	u8 result=0;
	while(GET_BIT(USCRA,RXC)==0)
	{

			/*if(GET_BIT(ADCSRA,ADIF)==1)
			{
				break;
			}*/


	}
	result=UDR;
	return result;
}
void RX_Enterrupt_Enable(void)
{
	Receiver_Enterrupt_Enable;
}
void RX_Enterrupt_Disable(void)
{
	Receiver_Enterrupt_Disable;
}
void SEND_Enterrupt_Enable(void)
{
	UDRE_Enterrupt_Enable;
}
