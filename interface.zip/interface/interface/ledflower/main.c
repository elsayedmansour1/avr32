#include<avr/io.h>
#include<avr/delay.h>
int main()
{
    DDRA=0b11111111;
  //  int x;
    int A1;
    int A2;
    while(1)
    {
   for(int x=0;x<4;x++)
        {
            A1=0b00000001<<x;
            A2=0b10000000>>x;
            PORTA=A1|A2;
   _delay_ms(200);
        }
 for(int y=1;y<4;y++)
    {
   A1=0b00001000>>y;
   A2=0b00010000<<y;
   PORTA=A1|A2;
     _delay_ms(200);
    }
    }
    }
