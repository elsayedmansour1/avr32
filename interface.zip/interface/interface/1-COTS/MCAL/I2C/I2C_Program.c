#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "avr/delay.h"
#include"DIO_Interface.h"
#include"I2C_Interface.h"
#include"I2C_Register.h"

void I2C_INIT(void)
{
	 TWBR=0x;
	 CLR_BIT(  );
	 SET_BIT(TWSR,TWPS0 );   	//prescaler0
	 SET_BIT(TWSR,TWPS1 );	//prescaler1
	 
	 SET_BIT(TWCR,TWEN );    	//I2C ENABLE
	 
	 SET_BIT(TWCR,TWINT );	//clear flag 
	 
	 SET_BIT(TWCR,TWEA ); 	//Enable Acknowledge Bit
}
void START_CONDITION(void)
{
	SET_BIT(TWCR,TWSTA);	//START Condition Bit
}
void STOP_CONDITION(void)
{
	SET_BIT(TWCR,TWSTO);	//STOP Condition Bit
}
void I2C_TANSCIEVER(void)
{
	while(GIt_BIT(TWCR,TWINT)==0);
	if ((TWSR & 0xF8) == START)
	{
		TWDR = SLA_W;
		SET_BIT(TWCR,TWINT );	//clear flag 
		while(GIt_BIT(TWCR,TWINT)==0);
		if ((TWSR & 0xF8) == MT_SLA_ACK)
		{
			TWDR = DATA;
			while (GIt_BIT(TWCR,TWINT);
			if ((TWSR & 0xF8) == MT_DATA_ACK)
			{
				
			}
				
		}
	}

	
	
	
}