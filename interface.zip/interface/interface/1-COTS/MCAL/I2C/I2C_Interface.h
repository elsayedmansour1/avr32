#ifndef _I2C_INTERFACE_H_
#define _I2C_INTERFACE_H_


/*TWI Bit Rate Register – TWBR*/
#define TWBR7  7
#define TWBR6  6
#define TWBR5  5
#define TWBR4  4
#define TWBR3  3
#define TWBR2  2
#define TWBR1  1
#define TWBR0  0
/*TWI Control Register – TWCR*/
#define TWINT  7
#define TWEA   6
#define TWSTA  5
#define TWSTO  4
#define TWWC   3
#define TWEN   2
#define –      1
#define TWIE   0
/*TWI Status Register – TWSR*/
#define TWS7   7
#define TWS6   6
#define TWS5   5
#define TWS4   4
#define TWS3   3
#define –      2
#define TWPS1  1
#define TWPS0  0
/*TWI Data Register – TWDR*/
#define TWD7  7
#define TWD6  6
#define TWD5  5
#define TWD4  4
#define TWD3  3
#define TWD2  2
#define TWD1  1
#define TWD0  0
/*TWI (Slave) Address Register – TWAR*/
#define TWA6    7
#define TWA5    6
#define TWA4    5
#define TWA3    4
#define TWA2    3
#define TWA1    2
#define TWA0    1
#define TWGCE   0






void I2C_INIT(void);
void START_CONDITION(void);
void STOP_CONDITION(void);
void I2C_TANSCIEVER(void);











#endif