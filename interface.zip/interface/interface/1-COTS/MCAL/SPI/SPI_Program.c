#include "STD_TYPES.h"
#include "BIT_Math.h"
#include"DIO_Interface.h"
#include"SPI_Interface.h"
#include"SPI_Register.h"



void SPI_INIT(void)
{

	SET_BIT(SPCR, SPE); //SPI Enable
	
	SET_BIT(SPCR, DORD); //Data Order
	SET_BIT(SPCR, MSTR); //Master/Slave Select
	
	SET_BIT(SPCR, CPOL); //Clock Polarity
	SET_BIT(SPCR, CPHA); //Clock Phase
	/*SPI Clock Rate*/
	SET_BIT(SPCR, SPR0);
	CLR_BIT(SPCR, SPR1);
	CLR_BIT(SPSR, SPI2X);
	
	SET_BIT(SPDR, LSB);
}
u8 SPI_Transceiver(u8 DATA)
{
	SPDR=DATA;
	while(GET_BIT(SPSR,SPIF)==0){}
	return SPDR;
}