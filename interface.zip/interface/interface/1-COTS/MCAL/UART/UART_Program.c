#include "STD_TYPES.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include"UART_Register.h"
#include"UART_Interface.h"
#include"UART_Configuration.h"

u8 Temporary_REG=0;

void UART_INIT(void)
{

	/*USART Control and Status Register B – UCSRB */
	Receiver_Enable;
	Transmitter_Enable;
	/*Character Size*/
	Eight_Bit;
	/*Register Select*/
	SET_BIT( Temporary_REG , URSEL );
	/*USART Mode Select*/
	CLR_BIT( Temporary_REG , UMSEL );
	/*Parity Mode*/
	CLR_BIT( Temporary_REG ,  UPM1 );
	CLR_BIT( Temporary_REG ,  UPM0 );
	/*Stop Bit Select*/
	CLR_BIT( Temporary_REG ,  USBS );
	/*Clock Polarity*/
	CLR_BIT( Temporary_REG , UCPOL );
	/*MOVING DATA*/
	UCSRC=Temporary_REG;
	
	UBRRH=0;
	UBRRL=51;
}