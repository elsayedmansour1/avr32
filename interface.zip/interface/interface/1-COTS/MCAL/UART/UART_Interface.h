#ifndef _UART_INTERFACE_H_
#define _UART_INTERFACE_H_


void UART_INIT(void);





















#endif