#ifndef _WDT_REGISTER_H_
#define _WDT_REGISTER_H_



#define WDTCR    *((volatile u8*)0x41)







#endif