#ifndef _WDT_INTERFACE_H_
#define _WDT_INTERFACE_H_

#define JTRF    4
#define WDRF    3
#define BORF    2
#define EXTRF   1
#define PORF    0
void WDT_ON(void);
void WDT_OFF(void);




















#endif