#include "STD_TYPES.h"
#include "BIT_Math.h"
#include"WDT_Register.h"
#include"WDT_Interface.h"

void WDT_ON(void)
{
	/*OFF*/
 CLR_BIT(WDTCR,PORF);
	/*ON*/
 SET_BIT(WDTCR,WDRF);
	/*prescaler*/
 SET_BIT(WDTCR,BORF);
 SET_BIT(WDTCR,EXTRF);
 CLR_BIT(WDTCR,PORF); 
}
void WDT_OFF(void)
{
	WDTCR=0xff;
	WDTCR=0x00;	
}