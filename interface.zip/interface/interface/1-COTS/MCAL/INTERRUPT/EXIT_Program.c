#include "STD_TYPES.h"
#include "DIO_Register.h"
#include"EXIT_Register.h"
#include"DIO_Interface.h"
#include "BIT_Math.h"
#include <avr/delay.h>

void EXTINT_VidINT(u8 LOC_u8INT_NUM)
{         
	switch(LOC_u8INT_NUM)
	{
	case 0:
	#if SENCE_MOOD==FALLING_EDGE
	 CLR_BIT(MCUCR, 0);
	 SET_BIT(MCUCR, 1);	
	#elif SENCE_MOOD==RISING_EDGE
	 SET_BIT(MCUCR, 1);
           SET_BIT(MCUCR, 0); 
	#elif SENCE_MOOD==ON_CHANGE
	 CLR_BIT(MCUCR, 1);
	 SET_BIT(MCUCR, 0);	
	#elif SENCE_MOOD==LOW_LEVEL
	CLR_BIT(MCUCR, 1);
          CLR_BIT(MCUCR, 0);
	#else
	#error "WRONG CHOOSE OF SENCE MOOD"
	#endif
	break;
	case 1:
	#if SENCE_MOOD1==FALLING_EDGE
	 CLR_BIT(MCUCR, 2);
	 SET_BIT(MCUCR, 3);	
	#elif SENCE_MOOD1==RISING_EDGE
	 SET_BIT(MCUCR, 2); 
	 SET_BIT(MCUCR, 3);
	#elif SENCE_MOOD1==ON_CHANGE
	 SET_BIT(MCUCR, 2);	
	 CLR_BIT(MCUCR, 3);
	#elif SENCE_MOOD1==LOW_LEVEL
	CLR_BIT(MCUCR, 2);
	CLR_BIT(MCUCR, 3);
	#else
	#error "WRONG CHOOSE OF SENCE MOOD"
	#endif
	break;
	case 2:
	#if SENCE_MOOD2==FALLING_EDGE
	 CLR_BIT(MCUCSR, 6);
	 	
	#elif SENCE_MOOD2==RISING_EDGE
	 SET_BIT(MCUCSR, 6);
           
	#else
	#error "WRONG CHOOSE OF SENCE MOOD"
	#endif
	break;	
	}
	

}
void EXTINT_VidEnable(u8 LOC_u8INT_NUM)
{
	switch(LOC_u8INT_NUM)
	{
		case 0: SET_BIT(GICR, 6);break;
		case 1:SET_BIT( GICR , 7 );break;
		case 2:SET_BIT(GICR, 5);break;
	}
	
}
void EXTINT_VidDisable(u8 LOC_u8INT_NUM)
{
	switch(LOC_u8INT_NUM)
	{
		case 0:CLR_BIT(GICR, 6);break;
		case 1:CLR_BIT( GICR , 7 );break;
		case 2:CLR_BIT(GICR, 5);break;
	}
	
}

void EXIT2(u8 Sense_Mode)
{
	DIO_VidSetPinDirection(PORTB,PIN2,INPUT);
	switch(Sense_Mode)
	case FALLING_EDGE:
	CLR_BIT(MCUCSR, 6);
	break;
	case RISING_EDGE:
	SET_BIT(MCUCSR, 6);
	break;
}

static void (*GPFunc)(void)=NULL;
void TCNT0_SetCallBack(void (*LocalPFunc)(void))
{
	GPFunc=LocalPFunc;
}
ISR_EXINT_2()
{
	if(GPFunc!=NULL)
	{
		GPFunc();
	}
}
/*void __vector_1(void)
{

	DIO_VidSetPinValue(PORTA,PIN0,1);
	_delay_ms(1000);
}
void __vector_2(void)
{

	DIO_VidSetPinValue(PORTA,PIN0,1);
	_delay_ms(1000);
}
void __vector_3(void)
{

	DIO_VidSetPinValue(PORTA,PIN0,1);
	_delay_ms(1000);
}*/