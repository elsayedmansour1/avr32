#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"



void KEYPAD_VidInit(void)
{
	DIO_VidSetPortDirection ( PORTA,0B00001111);
	DIO_VidSetPortValue	( PORTA, 0B11111111);
}
u8 GET_PressedKey(void)
{   u8 keypad_array[4][4]={{1,2,3,4},
		                   {5,6,7,8},
						   {9,10,11,12},
						   {13,14,15,16}};
	u8 col,row;
	u8 keypad_out=0;
	//s8 i=3;
	for(col=0;col<4;col++)
	{
		DIO_VidSetPinValue	( PORTA, col, 0);
		for(row=4;row<8;row++)
		{
			if(DIO_vidGitPinValue(PORTA,row)==0)
			{

				keypad_out= keypad_array[row-4][col];
				while(DIO_vidGitPinValue(PORTA,row)==0)
				{
					
				}
				_delay_ms(50);
			}



		}
		DIO_VidSetPinValue	( PORTA, col, 1);
	}
	//keypad_out=1;
return keypad_out;
}
u8 keypad_array[4][4]={{1 ,2 ,3,'+'},
		       {4 ,5 ,6,'-'},
		       {7 ,8 ,9,'*'},
             { ' ' , ' ' , '=' ,'/'}};

s8 y=0;
u8 ch=0;

//s8 y=keypad_out;
u8 GET_PressedKeyNew(void)
{

		u8 col,row;
		u8 keypad_out=0;
		u8 sum;
		u8 check=0;


			for(col=0;col<4;col++)
				{
				DIO_VidSetPinValue	( PORTA, col, 0);
				for(row=4;row<8;row++)
				{
				if(DIO_vidGitPinValue(PORTA,row)==0)
				{
					if(col==3 )             //for special character(+,-,*,/)
			    	{

					LCD_VidWriteData(keypad_array[row-4][col]);
					ch=keypad_array[row-4][col];

			    	}
				    else if (row==7)            //for special character(=,space)
					{
						LCD_VidWriteData(keypad_array[row-4][col]);

					    if(col==2)            //row=7,,col=2 that mean =
					    {
					  	check=1;
					    }
					    else
					    {
						check=0;
					    }
					}
				    else             //for any number.
			    	{
					keypad_out= keypad_array[row-4][col];
				//

				    }
					//y=keypad_out;
					sum=KEYPAD_VidCal(keypad_out,ch);
				while(DIO_vidGitPinValue(PORTA,row)==0)
				{

				}
				_delay_ms(50);
				}



				}
				DIO_VidSetPinValue	( PORTA, col, 1);
				}

			if(check==1)
			{
				return sum;
			}
			else
			{
				return keypad_out;
			}




}

s8 KEYPAD_VidCal(s8 x,u8 ch)
{


if(ch==keypad_array[0][3])
{
	y=y+x;
}
else if (ch==keypad_array[1][3])
{
	y=y-x;
}
else if (ch==keypad_array[2][3])
{
	y=y*x;
}
else if (ch==keypad_array[3][3])
{
	y=y/x;
}
else if (ch==0)
{
	y=x;
}


	return y;
}