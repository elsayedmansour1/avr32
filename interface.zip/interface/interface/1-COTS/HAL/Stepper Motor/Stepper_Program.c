#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Stepper_Interface.h"
#include "DIO_Interface.h"

	u8  x=0;

void stepper(u8 LOC_Port,u8 INPUT1,u8 INPUT2 ,u8 INPUT3 ,u8 INPUT4,u8 Direction)
{
	DIO_VidSetPinDirection(LOC_Port, INPUT1, OUTPUT);
	DIO_VidSetPinDirection(LOC_Port, INPUT2, OUTPUT);
	DIO_VidSetPinDirection(LOC_Port, INPUT3, OUTPUT);
	DIO_VidSetPinDirection(LOC_Port, INPUT4, OUTPUT);
	u16 y=500;

	switch(Direction)
	{
	case Forword:
		for(u16 i=0;i<y;i++)
		{

			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);

		}
		break;
	case Reverise:
		for(u16 i=0;i<y;i++)
		{
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
			_delay_ms(x);      
			DIO_VidSetPinValue(LOC_Port, INPUT1, HIGH);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, HIGH);
			_delay_ms(x);
		}
		break;
	}
}
void REST_Of_Stepper(u8 LOC_Port,u8 INPUT1,u8 INPUT2 ,u8 INPUT3 ,u8 INPUT4)
{
			DIO_VidSetPinValue(LOC_Port, INPUT1, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT2, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT3, LOW);
			DIO_VidSetPinValue(LOC_Port, INPUT4, LOW);
}
void SPEED_of_Stepper(u8 speed)
{
	x=speed;
}
