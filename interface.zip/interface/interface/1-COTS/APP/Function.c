#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "Function.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include "Keypad_Interface.h"
#include<avr/delay.h>

u8 value;
u8 value1;
u16 value2;
u16 value3;
u16 digital_value;
u16 digital_value2;
u16 DARK;
u16 LIGHT;
u16 temp;
u16 id=0;
u16 password=0;
u8 not_correct=0;
u8 counter=0;
void ID(void)
{
	while(1)
	{
	GoToXY(0,0);
		LCD_VidWriteString("ID:");
		value=GET_PressedKey();
		if(value!=0)
		{
			GoToXY(0,counter+3);
			LCD_VidWriteNumber(value);
	     	counter++;
	     	id=id*10+value;
		}
		else{}

		if(id==321&&counter==3)
		{
			GoToXY(1,0);
			LCD_VidWriteString("Correct ID");
			_delay_ms(200);
			id=0;
			counter=0;
			break;
		}
		else if(id!=321&&counter==3)
		{
			GoToXY(1,0);
		//	LCD_VidWriteNumber(id);
			LCD_VidWriteString("Incorrect ID");
			not_correct++;
			id=0;
			counter=0;
			CLEAR(0,3,7);
			CLEAR(1,0,15);
		}
		else{}
if(not_correct==3)
{
	not_correct=0;
	while(1)
	{
		GoToXY(0,0);
		LCD_VidWriteString("    ENTERED ID  ");
		GoToXY(1,0);
		LCD_VidWriteString("  3 TIMES WRONG   ");
		_delay_ms(2000);
	}
}	
	}
	
}

void PASSWORD(void)
{
	while(1)
	{
	GoToXY(0,0);
		LCD_VidWriteString("Password:");
		value1=GET_PressedKey();
		if(value1!=0)
		{
			GoToXY(0,counter+9);
			LCD_VidWriteNumber(value1);
			_delay_ms(200);
			GoToXY(0,counter+9);
			LCD_VidWriteData(42);
			password=password*10+value1;
			counter++;
		}
		if(password==123&&counter==3)
		{
			GoToXY(1,0);
			LCD_VidWriteString("Correct Password");
			counter=0;
			break;
		}
		else if(password!=123&&counter==3)
		{
			password=0;
			GoToXY(1,0);
			counter=0;
			LCD_VidWriteString("Incorrect Password");
			CLEAR(0,9,15);
			CLEAR(1,0,16);
			not_correct++;
		}
		if(not_correct==3)
		{
			while(1)
			{
				GoToXY(0,0);
				LCD_VidWriteString("   ENTERED PASS  ");
				GoToXY(1,0);
				LCD_VidWriteString("  3 TIMES WRONG   ");
				_delay_ms(2000);
			}
		}	
	}
	

}
void StartScreen(void)
{
	                GoToXY(0,0);
					LCD_VidWriteString("1-LM-35");
					GoToXY(0,10);
					LCD_VidWriteString("2-LDR");
					GoToXY(1,0);
					LCD_VidWriteString("3-DC_MOTOR");
}
void LM_35_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus)
{
			GoToXY(0,0);
		LCD_VidWriteString("LM-35")	;
		value2=ADC_GET_RESULT(LOC_u8SelectChannel,LOC_u8SelectStatus);
		digital_value=(value2*5000UL)/1024;
		temp=digital_value/10;
		GoToXY(1,0);
		LCD_VidWriteString("TEMP=");
		LCD_VidWriteNumber(temp);
		_delay_ms(500);
}
void LDR_SENSOR (u8 LOC_u8SelectChannel,u8 LOC_u8SelectStatus)
{
			GoToXY(0,0);
		LCD_VidWriteString("LDR");
		value3=ADC_GET_RESULT(LOC_u8SelectChannel,LOC_u8SelectStatus);
		digital_value2=(value3*5)/1024;
		DARK=(digital_value2*100)/4;

		LIGHT=100-DARK;
		GoToXY(1,0);
		LCD_VidWriteString("LIGHT=");
		LCD_VidWriteNumber(LIGHT);
		GoToXY(1,9);
		LCD_VidWriteData('%');

		_delay_ms(500);
		CLEAR(1,6,9);
}
