#ifnend _ASCII_H
#define _ASCII_H
#define a 097
#define b 098
#define c 099
#define d 100
#define e 101
#define f 102
#define g 103
#define h 104
#define i 105
#define j 106
#define k 107
#define l 108
#define m 109
#define n 110
#define o 111
#define p 112
#define q 113
#define r 114
#define s 115
#define t 116
#define u 117
#define v 118
#define w 119
#define x 120
#define y 121
#define z 122
#define A 065
#define B 066
#define C 067
#define D 068
#define E 069
#define F 070
#define G 071
#define H 072
#define I 073
#define J 074
#define K 075
#define L 076
#define M 077
#define N 078
#define O 079
#define P 080
#define Q 081
#define R 082
#define S 083
#define T 084
#define U 085
#define V 086
#define W 087
#define X 088
#define Y 089
#define Z 090


#endif