#include "STD_TYPES.h"
#include "BIT_Math.h"
#include "TCNT0_Register.h"
#include "TCNT0_Interface.h"
#include"TCNT0_Define.h"





static void (*GPFunc)(void)=NULL;
void TCNT0_SetCallBack(void (*LocalPFunc)(void))
{
	GPFunc=LocalPFunc;
}
ISR_ADC()
{
	if(GPFunc!=NULL)
	{
		GPFunc();
	}
}




void TCNT0_INIT(void)
{
	//TCCR0=192;
	OCR0=127;
#if Timer0_Mode==CTC_Timer_Mode
	CTC_Mode;
#endif
	prescaler_clk_256;
	Compare_Match_Interrupt_Enable;
	Normal_OC0_disconnected;
}
void TCNT1_INIT(void)
{


}
void TCNT2_INIT(void)
{
	TCNT2=192;
	/*clock selection*/
	CLR_BIT(TCCR2, CS20);
	SET_BIT(TCCR2, CS21);
	CLR_BIT(TCCR2, CS22);
	/*Compare Match Output Mode*/
	CLR_BIT(TCCR2, COM20);
	CLR_BIT(TCCR2, COM21);
	/*Interrupt Enable*/
	SET_BIT(TIMSK, TOIE2);
	CLR_BIT(TIMSK, OCIE2);
    /*waveform generation mode*/
	CLR_BIT(TCCR2, WGM21);
	CLR_BIT(TCCR2, WGM20);
}



void TCNT_INIT(void)
{
#if LOC_Timer==TIMER0
	TCNT0=192;
	/*clock selection*/
	CLR_BIT(TCCR0, CS00);
	SET_BIT(TCCR0, CS01);
	CLR_BIT(TCCR0, CS02);
	/*Compare Match Output Mode*/
	CLR_BIT(TCCR0, COM00);
	CLR_BIT(TCCR0, COM01);
	/*Interrupt Enable*/

	SET_BIT(TIMSK, TOIE0);
	CLR_BIT(TIMSK, OCIE0);
    /*waveform generation mode*/
	CLR_BIT(TCCR0, WGM01);
	CLR_BIT(TCCR0, WGM00);
#elif LOC_Timer==TIMER1
#elif LOC_Timer==TIMER2
	TCNT2=192;
	/*clock selection*/
	CLR_BIT(TCCR2, CS20);
	SET_BIT(TCCR2, CS21);
	CLR_BIT(TCCR2, CS22);
	/*Compare Match Output Mode*/
	CLR_BIT(TCCR2, COM20);
	CLR_BIT(TCCR2, COM21);
	/*Interrupt Enable*/
	SET_BIT(TIMSK, TOIE2);
	CLR_BIT(TIMSK, OCIE2);
    /*waveform generation mode*/
	CLR_BIT(TCCR2, WGM21);
	CLR_BIT(TCCR2, WGM20);
#else
#error "WRONG CHOOSE OF SENCE MOOD"
#endif
}
