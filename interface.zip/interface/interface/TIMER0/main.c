/*
 * main.c
 *
 *  Created on: Jun 27, 2020
 *      Author: elsay
 */
void TIMER_Func(void);

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"GIE_Interface.h"
#include"TCNT0_Interface.h"

u16 counter=0;
void main(void)
{
	DIO_VidSetPinDirection(PORTC,PIN1,OUTPUT);
	TCNT0_INIT();
	SREG_VidEnable();
	TCNT0_SetCallBack(TIMER_Func);
	while(1)
	{

	}
}






void TIMER_Func(void)
{
	static u16 counter=0;
	counter++;
	if(counter==244)
	{
		DIO_VidSetPinValue(PORTC,PIN1,1);
	}
}
