#ifndef _TCNT0_DEFINE_H_
#define _TCNT0_DEFINE_H_

            /*TIMSK REGISTER*/
#define OCIE2     7  //output compare Interrupt Enable in TIMER 2
#define TOIE2     6  //TIMER 2 overflow Interrupt Enable
#define TICIE1    5  //Input Capture Interrupt Enable in TIMER 1
#define OCIE1A    4  //output compare A Interrupt Enable in TIMER 1
#define OCIE1B    3  //output compare B Interrupt Enable in TIMER 1
#define TOIE1     2  //TIMER 1 overflow Interrupt Enable
#define OCIE0     1  //output compare Interrupt Enable in TIMER 0
#define TOIE0     0  //TIMER 0 overflow Interrupt Enable

/****************************************************************************************************************/
/****************************************************************************************************************/
             /*TCCR2*/
#define FOC2     7   //force output compare
#define WGM20    6   //waveform generation mode 20
#define COM21    5   //compare output mode 1
#define COM20    4   //compare output mode 0
#define WGM21    3   //waveform generation mode 21
#define CS22     2   //clock selection 22
#define CS21     1   //clock selection 21
#define CS20     0   //clock selection 20

/****************************************************************************************************************/
/****************************************************************************************************************/
                /*TCCR0 REGISTER*/
#define FOC0      7 //force output compare

#define WGM00     6 //waveform generation mode 00
#define WGM01     3 //waveform generation mode 01

#define COM01     5 //compare output mode 1
#define COM00     4 //compare output mode 0

#define CS02      2 //clock selection 02
#define CS01      1 //clock selection 01
#define CS00      0 //clock selection 00
/****************************************************************************************************************/
/****************************************************************************************************************/

                /*TIMER 2*/
#define OCIE2     7  //output compare Interrupt Enable in TIMER 2
#define TOIE2     6  //TIMER 2 overflow Interrupt Enable

/****************************************************************************************************************/
/****************************************************************************************************************/
				/*TIMER 1*/
#define TICIE1    5  //Input Capture Interrupt Enable in TIMER 1
#define OCIE1A    4  //output compare A Interrupt Enable in TIMER 1
#define OCIE1B    3  //output compare B Interrupt Enable in TIMER 1
#define TOIE1     2  //TIMER 1 overflow Interrupt Enable

/****************************************************************************************************************/
/****************************************************************************************************************/
                /*TIMER 0*/
#define OCIE0     1  //output compare Interrupt Enable in TIMER 0
#define TOIE0     0  //TIMER 0 overflow Interrupt Enable

/****************************************************************************************************************/
/****************************************************************************************************************/
                /*MODES*/
#define Normal      	   CLR_BIT(TCCR0, WGM01);\
	                       CLR_BIT(TCCR0, WGM00);

#define PWM_Phase_Correct  CLR_BIT(TCCR0, WGM01);\
	                       SET_BIT(TCCR0, WGM00);

#define CTC_Mode           SET_BIT(TCCR0, WGM01);\
	                       CLR_BIT(TCCR0, WGM00);

#define Fast_PWM           SET_BIT(TCCR0, WGM01);\
		                   SET_BIT(TCCR0, WGM00);

#define Normal_Timer_Mode     0
#define PWM_Timer_Mode        1
#define CTC_Timer_Mode        2
#define Fast_PWM_Timer_Mode	  3



/********************************/

#define Timer0_Mode  CTC_Timer_Mode

/********************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

    /*Compare Output Mode, non-PWM Mode*/
#define Normal_OC0_disconnected         CLR_BIT(TCCR0,COM01);\
	                                    CLR_BIT(TCCR0,COM00);

#define Toggle_OC0_on_compare_match     CLR_BIT(TCCR0,COM01);\
										SET_BIT(TCCR0,COM00);

#define Clear_OC0_on_compare_match      SET_BIT(TCCR0,COM01);\
										CLR_BIT(TCCR0,COM00);

#define Set_OC0_on_compare_match        SET_BIT(TCCR0,COM01);\
										SET_BIT(TCCR0,COM00);
#define OC0_disconnected     0
#define Toggle_OC0           1
#define Clear_OC0            2
#define Set_OC0              3





/*********************************************/

#define Compare_Output_Mode OC0_disconnected

/*********************************************/



/****************************************************************************************************************/
/****************************************************************************************************************/
             /*Compare Output Mode, Fast PWM Mode*/
#define Normal_OC0_disconnected        		          CLR_BIT(TCCR0,COM01);\
	                                                  CLR_BIT(TCCR0,COM00);

#define Reserved                                      CLR_BIT(TCCR0,COM01);\
	                                                  SET_BIT(TCCR0,COM00);

#define Clear_OC0_on_compare_match_set_OC0_at_TOP     SET_BIT(TCCR0,COM01);\
	                                                  CLR_BIT(TCCR0,COM00);

#define Set_OC0_on_compare_matchclear_OC0_at_TOP      SET_BIT(TCCR0,COM01);\
	                                                  SET_BIT(TCCR0,COM00);

#define Normal_Mode                               0
#define reserved_mode                             1
#define OCO_on_Compare_an_TOP_Clear_And_Set	      2
#define OCO_on_Compare_an_TOP_Set_And_Clear	      3





/*************************************/

#define Fast_PWM_MODE  Normal_Mode

/************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/

                    /*Clock Select*/
#define Timer_Counter stopped          		 CLR_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
					                         CLR_BIT(TCCR0,CS00);

#define No_prescaling                 	   	 CLR_BIT(TCCR0,CS02);\
											 CLR_BIT(TCCR0,CS01);\
											 SET_BIT(TCCR0,CS00);

#define prescaler_clk_8 	          		 CLR_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
	                                         CLR_BIT(TCCR0,CS00);

#define prescaler_clk_64    			 	 CLR_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
	                                         SET_BIT(TCCR0,CS00);

#define prescaler_clk_256   				 SET_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
	                                         CLR_BIT(TCCR0,CS00);

#define prescaler_clk_1024 	              	 SET_BIT(TCCR0,CS02);\
	                                         CLR_BIT(TCCR0,CS01);\
					                         SET_BIT(TCCR0,CS00);

#define External_Clock_on_falling_edge 	     SET_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
					                         CLR_BIT(TCCR0,CS00);

#define External_Clock_on_rising_edge		 SET_BIT(TCCR0,CS02);\
	                                         SET_BIT(TCCR0,CS01);\
					                         SET_BIT(TCCR0,CS00);

#define 	prescaler_0                   0
#define 	prescaler_1                   1
#define 	prescaler_8                   8
#define 	prescaler_64                  64
#define 	prescaler_256                 256
#define 	prescaler_1024                1024
#define 	External_falling_edge         2
#define     External_rising_edge	      3




/****************************************/

#define clock_select  prescaler_256

/****************************************/


/****************************************************************************************************************/
/****************************************************************************************************************/
                    /*INTERRUPT MODE*/
#define Compare_Match_Interrupt_Enable        SET_BIT(TIMSK,OCIE0);\
                                              CLR_BIT(TIMSK,TOIE0);

#define Overflow_Interrupt_Enable             CLR_BIT(TIMSK,OCIE0);\
                                              SET_BIT(TIMSK,TOIE0);

#define CM_Interrupt_Enable    0
#define OF_Interrupt_Enable    1
/**********************************************/

#define INTERRUPT_MODE  CM_Interrupt_Enable

/*********************************************/

#endif
