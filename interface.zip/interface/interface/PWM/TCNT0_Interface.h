#ifndef _TCNT0_INTERFACE_H_
#define _TCNT0_INTERFACE_H_


#define ISR_TMR(TO_COM)  void __vector_10(void)__attribute__((signal));\
	               void __vector_10(void)
//#define ISR_TMR(T0_OVF)  void __vector_10(void)__attribute__((signal));\
	               void __vector_10(void)
//#define ISR_TMR(T2_COM)  void __vector_10(void)__attribute__((signal));\
	               void __vector_10(void)
//#define ISR_TMR(T2_OVF)  void __vector_10(void)__attribute__((signal));\
	               void __vector_10(void)



void TCNT0_INIT(void);
void TCNT1_INIT(void);
void TCNT2_INIT(void);

void Set_Duty_Cycle(f32 Value);

void TCNT0_SetCallBack(void (*LocalPFunc)(void));
















#endif
