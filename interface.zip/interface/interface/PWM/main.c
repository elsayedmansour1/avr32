/*
 * main.c
 *
 *  Created on: Jun 27, 2020
 *      Author: elsay
 */
void TIMER_Func(void);

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"GIE_Interface.h"
#include"TCNT0_Interface.h"

void main(void)
{
	DIO_VidSetPinDirection(PORTD,PIN5,OUTPUT);
	TCNT1_INIT();

	while(1)
	{
	Set_Duty_Cycle(2.5);
	_delay_ms(1000);
	Set_Duty_Cycle(7.4);
	_delay_ms(1000);
	Set_Duty_Cycle(12.5);
	_delay_ms(1000);


	}
}






void TIMER_Func(void)
{
	static u16 counter=0;
	counter++;
	if(counter==244)
	{
		DIO_VidSetPinValue(PORTC,PIN1,1);
	}
}
