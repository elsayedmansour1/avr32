/*
 * man.c
 *
 *  Created on: Aug 21, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include "LCD_Interface.h"

void main(void)
{

	LCD_VidInit();
	_delay_ms(100);
	while(1)
	{
		LCD_GoToXY(0, 5);
		LCD_VidWriteString("ELSAYED5");

		_delay_ms(1000);
		LCD_VidWriteCommend(1);

		_delay_ms(1000);


	}

}
