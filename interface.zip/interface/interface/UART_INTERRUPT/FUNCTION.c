/*
 * FUNCTION.C
 *
 *  Created on: Jul 17, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include "util/delay.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"FUNCTION.h"
#include"TIMER_Interface.h"
u8  arr_size=0;
u8  arr[16];
u8  corr_arr[16]={97,100,109,105,110};
u8  counter_right=0;
u8  counter_wrong=0;
u8 out=0;
u8  confirm=0;
u8 ID(u8 data)
{
	LCD_GoToXY(0, 0);
	LCD_VidWriteString("ID:");

	    	LCD_GoToXY(0, arr_size+3);
	    	LCD_VidWriteData(data);                  //To show the receive data on LCD
	    	arr[arr_size]=data;						//collect received data in array
	        arr_size++;
			if(arr_size==5)
			   {
				//LCD_GoToXY(1, 0);
				for(u8 z=0;z<5;z++)
					{
						if(arr[z]==corr_arr[z])		//check the received data is the same in corr_arr
						{
							counter_right++;
						}
						else{}
					}

				if(arr_size==5 && counter_right==5)         //if the received data is the same in corr_arr
				{
					LCD_GoToXY(1, 0);
					LCD_VidWriteString("Correct ID");
					_delay_ms(1000);
					LCD_VidWriteCommend(1);                        //clear LCD
					arr_size=0;
					counter_right=0;
					counter_wrong=0;
					out=1;
					return out;
				}
				else if(arr_size==5 && counter_right!=5)
				{
					LCD_GoToXY(1, 2);
					LCD_VidWriteString("Incorrect ID");
					_delay_ms(1000);
					LCD_GoToXY(1, 4);
					LCD_VidWriteString("Try Again");
					_delay_ms(1000);
					LCD_VidWriteCommend(1);                        //clear LCD
					arr_size=0;
					counter_right=0;
					counter_wrong++;
					if(counter_wrong ==3)
					{
						LCD_VidWriteCommend(1);                        //clear LCD
						while(1)
						{
							LCD_GoToXY(0, 2);
							LCD_VidWriteString("No more Tries");
							LCD_GoToXY(1, 2);
							LCD_VidWriteString("No more Tries");
						}


					}
				}
				else{}

			   }

	 return 0;
}
u8 PASSWORD(u8 data)
{
	LCD_GoToXY(0, 0);
	LCD_VidWriteString("PASSWORD:");

		 	 LCD_GoToXY(0, arr_size+9);
	    	LCD_VidWriteData(data);                  //To show the receive data on LCD
	    	LCD_GoToXY(0, arr_size+9);
	    	_delay_ms(200);
	    	LCD_VidWriteData('*');
	    	arr[arr_size]=data;						//collect received data in array
	        arr_size++;;
			if(arr_size==5)
			   {
				//LCD_GoToXY(1, 0);
				for(u8 z=0;z<5;z++)
					{
						if(arr[z]==corr_arr[z])		//check the received data is the same in corr_arr
						{
							counter_right++;
						}
						else{}
					}

				if(arr_size==5 && counter_right==5)         //if the received data is the same in corr_arr
				{
					LCD_GoToXY(1, 0);
					LCD_VidWriteString("Correct");
					_delay_ms(1000);
					LCD_VidWriteCommend(1);                        //clear LCD
					arr_size=0;
					counter_right=0;
					counter_wrong=0;
					out=2;
					return out;
				}
				else if(arr_size==5 && counter_right!=5)    //if the received data isn't the same in corr_arr
				{
					LCD_GoToXY(1, 4);
					LCD_VidWriteString("Incorrect ");
					_delay_ms(1000);
					LCD_GoToXY(1, 4);
					LCD_VidWriteString("Try Again");
					_delay_ms(1000);
					LCD_VidWriteCommend(1);                        //clear LCD
					arr_size=0;
					counter_right=0;
					counter_wrong++;
					if(counter_wrong ==3)
					{
						LCD_VidWriteCommend(1);                        //clear LCD
						while(1)
						{
							LCD_GoToXY(0, 2);
							LCD_VidWriteString("No more Tries");
							LCD_GoToXY(1, 2);
							LCD_VidWriteString("No more Tries");
						}


					}
				else{}

			   }
	    }

	 return 1;
}
void SYSTEM_LOADING(void)
{
	LCD_GoToXY(0,0);
	LCD_VidWriteString("SYSTEM_LOADING");
	LCD_GoToXY(1,0);
	for(u8 x=0;x<15;x++)
	{
		LCD_VidWriteData('>');
		_delay_ms(100);
	}

}
void StartScreen(void)
{
    LCD_GoToXY(0,1);
	LCD_VidWriteString("1-LM-35");
	LCD_GoToXY(0,11);
	LCD_VidWriteString("2-LDR");
	LCD_GoToXY(1,1);
	LCD_VidWriteString("3-DC_MOTOR");
}
u8 Controll(u8 data)
{
	 u8 customChar[] = {0x10,0x18,0x1C,0x1E,0x1C,0x18,0x10,0x00};

	 u8 confirm1=0;

		if(data=='l')   																//                //
		{                                                                               //
			LCD_CLEAR( 1,  0,  1);
			LCD_CLEAR( 0, 10, 11);
			LCD_CONSTANT(customChar, 8, 0, 0, 1);
			confirm=1;
		}
		else if(data=='r')
		{
			LCD_CLEAR( 1, 0, 1);
			LCD_CLEAR( 0, 0, 1);
			LCD_CONSTANT(customChar, 8, 0, 10, 1);
			confirm=2;
		}
		else if(data=='d')
		{
			LCD_CLEAR( 0,  0,  1);
			LCD_CLEAR( 0, 10, 11);
			LCD_CONSTANT(customChar, 8, 1, 0, 1);
			confirm=3;
		}


return confirm;

}
u8 Controll2(u8 data)
{
	u8 x=0;
	if(data=='e')
	{
		x=1;
	}
	return x;
}
void DC_MOTOR (u8 data,u8 flag)
{
	if(flag==3)
	{
		LCD_GoToXY(0,0);
		LCD_VidWriteString("DC_MOTOR");
		LCD_GoToXY(1,0);
		LCD_VidWriteString("Duty_Cycle=");
		if(data>100)
		{
			LCD_VidWriteNumber(0);                  //To show the receive data on LCD
		}
		else
		{
			LCD_VidWriteNumber(data*10);                  //To show the receive data on LCD
		}
		LCD_GoToXY(1,13);
		LCD_VidWriteString("%");
		Set_Duty_Cycle(data);
	}
}
