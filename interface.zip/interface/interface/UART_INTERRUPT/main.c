/*
 * main.c
 *
 *  Created on: Jul 17, 2020
 *      Author: elsay
 */

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"GIE_Interface.h"
#include"FUNCTION.h"
#include"ADC_Interface.h"
#include"ADC_Register.h"
#include"TIMER_Interface.h"

void RX_FUNC(void);
void LM_35_SENSOR (void);
void DC_MOTOR1(u8 data);

u8 DATA=0;
u8 value=0;
u8 value2=0;
u8 stop=0;
u8 flag=0;
u8 counter=0;
u8 counter1=0;
u8 X=0;

void main(void)
{


	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX
	DIO_VidSetPinDirection(PORTD,PIN7,OUTPUT);  //motor


	LCD_VidInit();
	UART_INIT();
	ADC_INIT();									//ADC Initialization
	TIMER2_INIT();								//TIMER2 Initialization

	GIE_VidEnable();

	RX_SetCallBack(RX_FUNC);
	ADC_SetCallBack(LM_35_SENSOR);
	LCD_GoToXY(0, 4);
	LCD_VidWriteString("Welcome");
	_delay_ms(1000);
	LCD_VidWriteCommend(1);
	LCD_GoToXY(0, 0);
	LCD_VidWriteString("ID:");
	ADC_GET_RESULT();


	RX_Enterrupt_Enable();

	DIO_VidSetPinDirection(PORTC,PIN7,OUTPUT);  //LED FOR LM
	DIO_VidSetPinDirection(PORTC,PIN6,OUTPUT);  //LED FOR LDR
	while(1)
	{
		if(counter==1)
			{
			ADC_CHECKMODE(INTERRUPT);
			LCD_VidWriteCommend(1);
			ADC_SELECT_CHANNAL(ADC0);
			flag=1;
			StartConversion();
			}
		else if (counter==2)
			{
			ADC_CHECKMODE(INTERRUPT);
			LCD_VidWriteCommend(1);
			ADC_SELECT_CHANNAL(ADC1);
			flag=2;
			StartConversion();
			}
	}

}


void RX_FUNC(void)
{
	DATA=UDR;

if(stop==0)
{
	stop=ID(DATA);
}
else if(stop==1)
{
	stop=PASSWORD(DATA);

}
else if(stop==2)
{
	LCD_VidWriteString("Welcome Elsayed");
	_delay_ms(1000);
	LCD_VidWriteCommend(1);
	SYSTEM_LOADING();
	LCD_VidWriteCommend(1);
	stop=3;
}
else if(stop==3)
{

	 StartScreen();
	 _delay_ms(500);
	 stop=4;
}
else if(stop==4)
{
	value=Controll(DATA);
	value2=Controll2(DATA);
	if(value==1 && value2==1)                 //for lm-35
	{
    counter=1;
	}
	else if(value==2 && value2==1)			//for LDR
	{
	counter=2;
	}
	else if((value==3 && value2==1)||flag==3)    //
	{
		if(DATA!=13 && DATA!=10)                       //to avoid common wrong
		{
			flag=3;
			LCD_VidWriteCommend(1);
			DC_MOTOR(DATA,flag);
			 if(DATA=='s')
			{

				LCD_VidWriteCommend(1);
				DC_MOTOR(0,flag);
				flag=0;

			}
		}



	}
	else if(DATA=='m')
	{
		LCD_VidWriteCommend(1);
		Interrupt_Disable();
		counter=0;
		value=0;
		value2=0;
		flag=0;
		stop=3;
	}
}
}

void LM_35_SENSOR (void)
{

		u16 digital_value;
		u8 temp;

if(flag==1)
{
	digital_value=( ADC *5000UL)/1024;
    temp=digital_value/10;

		    	LCD_GoToXY(0,0);
				LCD_VidWriteString("LM-35")	;

				LCD_GoToXY(0,8);
				LCD_VidWriteString("BUZZER:")	;



				LCD_GoToXY(1,0);
				LCD_VidWriteString("TEMP=");
				LCD_VidWriteNumber(temp);
				LCD_VidWriteString("C");
				if(temp>40)
				{
					DIO_VidSetPinValue(PORTC,PIN6,HIGH);
					LCD_GoToXY(1,10);
					LCD_VidWriteString("ON")	;
				}
				else
				{
					DIO_VidSetPinValue(PORTC,PIN6,LOW);
					LCD_GoToXY(1,10);
					LCD_VidWriteString("OFF")	;
				}
				_delay_ms(500);
				LCD_CLEAR(1,10,15);
}
else if(flag==2)
{
		u16 digital_value2=0;
		u8 DARK=0;
		u8 LIGHT=0;
		digital_value2=(ADC*5)/1023;
		DARK=(digital_value2*100)/4;
		LIGHT=100-DARK;
		LCD_GoToXY(0,0);
		LCD_VidWriteString("LDR")	;
		LCD_GoToXY(0,7);
		LCD_VidWriteString("LED:")	;

		LCD_GoToXY(1,0);
		LCD_VidWriteString("LIGHT=");
		LCD_VidWriteNumber(LIGHT);
		LCD_GoToXY(1,9);
		LCD_VidWriteData('%');
		if(LIGHT<25)
		{
			DIO_VidSetPinValue(PORTC,PIN7,HIGH);
			LCD_GoToXY(0,11);
			LCD_VidWriteString("ON")	;
		}
		else
		{
			DIO_VidSetPinValue(PORTC,PIN7,LOW);
			LCD_GoToXY(0,11);
			LCD_VidWriteString("OFF")	;

		}
		_delay_ms(500);
		LCD_CLEAR(0,11,15);
		LCD_CLEAR(1,6,9);


	}
}
void LM_35_SENSOR1(u8 data)
{

}
void LDR2(u8 data)
{

}
void DC_MOTOR1(u8 data)
{

}
