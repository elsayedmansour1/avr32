/*
 * FUNCTION.h
 *
 *  Created on: Jul 17, 2020
 *      Author: elsay
 */


u8 ID(u8 data);
u8 PASSWORD(u8 data);
void SYSTEM_LOADING(void);
void StartScreen(void);
u8 Controll(u8 data);
u8 Controll2(u8 data);
void DC_MOTOR (u8 data,u8 flag);
