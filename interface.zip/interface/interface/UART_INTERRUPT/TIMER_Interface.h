#ifndef _TCNT0_INTERFACE_H_
#define _TCNT0_INTERFACE_H_





void TIMER0_INIT(void);
void TIMER1_INIT(void);
void TIMER2_INIT(void);

void TIMER1_Input_Capture_Enable(void);
void TIMER2_Interrupt_Enable(void);

void Set_Duty_Cycle(f32 Value);

void T2_Ovf_SetCallBack(void (*LocalPFunc)(void));
















#endif
