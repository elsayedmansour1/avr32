/*
 * Function.h
 *
 *  Created on: Jul 14, 2020
 *      Author: elsay
 */

void ID(u8 DATA);

