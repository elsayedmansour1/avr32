#ifndef _GIE_INTERFACE_H_
#define _GIE_INTERFACE_H_





void GIE_VidEnable(void);
void GIE_VidDisable(void);



















#endif
