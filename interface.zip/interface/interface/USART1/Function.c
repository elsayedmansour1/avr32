/*
 * Function.c
 *
 *  Created on: Jul 14, 2020
 *      Author: elsay
 */
#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"UART_Interface.h"
#include"UART_Configuration.h"
#include"LCD_Interface.h"
#include"Function.h"




 u8  arr[16];
 u8  corr_arr[16]={97,100,109,105,110};
 u8  arr_size=0;
 u8  counter_right=0;
 u8  counter_wrong=0;
 u8 customChar[] = {0x10,0x18,0x1C,0x1E,0x1C,0x18,0x10,0x00};

void ID(u8 DATA)
{
	LCD_GoToXY(0, 0);
	LCD_VidWriteString("ID:");
	while(1)
	{

		    if(DATA!=0 && DATA!=13 && DATA!=10)                       //to avoid common wrong
		    {
		    	LCD_GoToXY(0, arr_size+3);
		    	LCD_VidWriteData(DATA);                  //To show the receive data on LCD
		    	//USART_Transmit(DATA);   				//To send the same data to controller device
		    	arr[arr_size]=DATA;						//collect received data in array
		        arr_size++;


			if(arr_size==5)
			   {
				//LCD_GoToXY(1, 0);
				for(u8 z=0;z<5;z++)
					{
						if(arr[z]==corr_arr[z])		//check the received data is the same in corr_arr
						{
							counter_right++;
						}
					}

			   }
			if(arr_size==5 && counter_right==5)         //if the received data is the same in corr_arr
			{
				LCD_GoToXY(1, 0);
				LCD_VidWriteString("Correct");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				arr_size=0;
				counter_right=0;
				counter_wrong=0;
				break;
			}
			else if(arr_size==5 && counter_right!=5)    //if the received data isn't the same in corr_arr
			{
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Incorrect");
				_delay_ms(1000);
				LCD_GoToXY(1, 4);
				LCD_VidWriteString("Try Again");
				_delay_ms(1000);
				LCD_VidWriteCommend(1);                        //clear LCD
				arr_size=0;
				counter_right=0;
				counter_wrong++;
				if(counter_wrong ==3)
				{
					LCD_VidWriteCommend(1);                        //clear LCD
					while(1)
					{
						LCD_GoToXY(0, 2);
						LCD_VidWriteString("No more Tries");
						LCD_GoToXY(1, 2);
						LCD_VidWriteString("No more Tries");
					}


				}
			}

		    }
	}
}
