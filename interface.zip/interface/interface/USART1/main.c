/*
 * main.c
 *
 *  Created on: Jul 11, 2020
 *      Author: elsay
 */

void RX_FUNC(void);
void UDRE_FUNC(void);

#include"STD_TYPES.h"
#include"BIT_Math.h"
#include<avr/delay.h>
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"UART_Interface.h"
#include"UART_Register.h"
#include"UART_Configuration.h"
#include"GIE_Interface.h"
#include"Function.h"
u8 DATA=0;
void main(void)
{


	DIO_VidSetPinDirection(PORTD,PIN0,INPUT);   //RX
	DIO_VidSetPinDirection(PORTD,PIN1,OUTPUT);  //TX
	DIO_VidSetPinDirection(PORTC,PIN7,OUTPUT);

	LCD_VidInit();
	UART_INIT();
	GIE_VidEnable();
	RX_SetCallBack(RX_FUNC);
	//UDRE_SetCallBack(UDRE_FUNC);


	LCD_VidWriteString("ELSAYED");
	_delay_ms(1000);
	LCD_VidWriteCommend(1);
	u8 data=0;
	//SEND_Enterrupt_Enable();
	//RX_Enterrupt_Enable();
	ID(DATA);
while(1)
{
	TOG_BIT( *((volatile u8*)0x35),PIN7);
	_delay_ms(100);
}
}
void RX_FUNC(void)
{

	DATA=UDR;
    if(DATA!=13 && DATA!=10)                       //to avoid common wrong
    {
    	LCD_GoToXY(0, 0);
    	LCD_VidWriteNumber(DATA);

    }
}
/*void UDRE_FUNC(void)
{
	if(DATA!=0)
	{
		if(DATA!=13 && DATA!=10)
			{
				  UDR=DATA;
			}
		//DATA=0;
	}


}*/
