#include<avr/io.h>
#include<avr/delay.h>
int main()
{
	DDRB=0XFF;
	PORTB=0XFF;

}
