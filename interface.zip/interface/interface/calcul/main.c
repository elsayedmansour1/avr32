/*
 * main.c
 *
 *  Created on: Jun 10, 2020
 *      Author: elsay
 */

#include "STD_TYPES.h"
#include "LCD_Interface.h"
#include "BIT_Math.h"
#include "DIO_Interface.h"
#include<avr/delay.h>
#include "Keypad_Interface.h"
void main(void)
{
	u8 keypad_out,sign,equal;
	LCD_VidInit();
	KEYPAD_VidInit();
	u8 value1=0;
	u8 value2=0;
	u8 value3=0;
	u8 sum=0;
	u8 mult=1;
	u8 sub=0;
	u8 div=1;
u8 	counter=0;
u8 num1=0;

	while(1)
	{
		keypad_out=GET_PressedKeyNew();
	    sign=KEYPAD_SIGN();
	    equal=KEYPAD_EQUAL();

	if(keypad_out!=0)
	{
		LCD_VidWriteNumber(keypad_out);
		value1=keypad_out;
		counter++;

	}
	else if(sign!=0)
		{
			LCD_VidWriteData(sign);
			value2=sign;

		}
	else if(equal!=0)
			{
				LCD_VidWriteData(equal);
				value3=equal;

			}

	 if(value2==0&&value1!=0)
	    {
	    	num1=num1*10+value1;
	    	value1=0;
	    }


    if(value2==43&&counter>0)
	{
		sum=sum+num1;

		  counter=0;

	}
    else if(value2==45&&counter>0)
    	{
    	if(sub>value1)
    	{
    		sub=256-sub-value1;

    		    		  counter=0;
    	}


    	}



    else  if(value2==42&&counter>0)
    	{
    		mult=mult*value1;

    		  counter=0;

    	}
    else if(value2==44 &&counter>0)
    	{
    		div=value1/div;

    		  counter=0;

    	}



	if (value3==61)
	{
		if(value2==43)
		{
			LCD_VidWriteNumber(sum);
					value3=0;
		}
		else if(value2==42)
				{
					LCD_VidWriteNumber(mult);
							value3=0;
				}
		else if(value2==45)
						{
							LCD_VidWriteNumber(sub);
									value3=0;
						}
		else if(value2==44)
						{
							LCD_VidWriteNumber(div);
									value3=0;
						}



	}



	}
}
