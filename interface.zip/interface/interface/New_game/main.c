
#include "STD_TYPES.h"
#include "DIO_Register.h"
#include "BIT_Math.h"
#include <avr/delay.h>
#include "Keypad_Interface.h"
#include "DIO_Interface.h"
#include"LCD_Interface.h"
 void main(void)
 {
	 u8  gool_up  [8]=  {0x10,  0x18,  0x14,  0x12,  0x11,  0x11,  0x11,  0x11       };
	 u8  gool_down[8]=   {0x11,  0x11,  0x11,  0x11,  0x09,  0x05,  0x03,  0x01    };
	 u8  body_face [8] = {  0x04,  0x0A,  0x04,  0x0E,  0x15,  0x04,  0x0A,  0x0A};
	//  u8  ball_up     [10]= {  0x0E,  0x1F,  0x1F,  0x0E,  0x00,  0x00, 0x00, 0x00};
	 u8  ball_down     [8]= { 0x00, 0x00,  0x00,  0x00,  0x0E,  0x1F,  0x1F,  0x0E   };
	 u8  gool_up_right  [8]=  {  0x10,  0x18,  0x14,  0x12,    0x11,  0x11,  0x11};
	 u8  gool_down_right  [8]= {  0x11,  0x11,  0x11,  0x11,  0x09,  0x05,  0x03,  0x01};
	 u8 loading[15]={'>','>','>','>','>','>','>','>','>','>','>','>','>','>','>','>','>'};
	 //u8 empty[8]={0,0,0,0,0,0,0,0};
		u8 num1=0;
		u8 num2=0;
		u8 num3=0;
		u8 num4=0;
		u8 counter;
		LCD_VidInit();
		KEYPAD_VidInit();
		GoToXY(0,1);
		LCD_VidWriteString("FOOTBALL GAME");
		GoToXY(1,2);
		LCD_VidWriteString(" PRESS ENTER ");
		_delay_ms(1000);
		GoToXY(0,0);
		while(1)
		{
			  u8 value4=START();
			  if(value4!=0)
			  {
				  break;
			  }
		}
		LCD_VidWriteCommend(1);
		LCD_VidWriteString("LOADING");
		GoToXY(1,0);
		for(u8 i=0;i<15;i++)
		{
			LCD_VidWriteData(loading[i]);
			_delay_ms(100);
		}
		GoToXY(0,0);

while(1)
{
	u8 value1= playerone();
	u8 value2=playerotwo();
	u8 value3=shooot();



	if(value1!=0)
	{num1=value1;
		if(value1==1)
				{num1=value1;
			LCD_VidWriteCommend(1);
		constant2(1);
				}
		else if(value1==2)
						{num2=value1;
			LCD_VidWriteCommend(1);
			constant2(2);
						}
	}
	else if(value2!=0)
		{
		if(value2==1)
				{num3=value2;
			LCD_VidWriteCommend(1);
			constant2(3);
				}
		else if(value2==2)
						{
			num4=value2;
			LCD_VidWriteCommend(1);
			/*if(counter==1)
			{constant2(5);
						}*/
						}
		}
	else if(value3!=0)
		{

			if(num1==1)
			{
				if(num1==1 && counter==0)
			    {
				  for(u8 i=2;i<=13;i++)
				  {
					  LCD_VidWriteCommend(1);
					  constant2(1);
					  constant(ball_down,48,0,i,6);
					  _delay_ms(200);
				      counter++;
				  }
			    }
			   else  if(num1==1 && counter>0)
				   {
				  for(u8 i=13;i>=2;i--)
				  {
					  LCD_VidWriteCommend(1);
					  constant2(1);
					constant(ball_down,48,0,i,6);
					_delay_ms(200);
					 // num1=0;
					  counter=0;
	              }

	              }

			}
			else if(num2==2)
			{
				 for(u8 i=2;i<=13;i++)
					              {
					                LCD_VidWriteCommend(1);
					                if(i==13)
									{value3=0;
									 constant2(5);
									 constant(ball_down,48,1,13,6);
									 if(value3==3)
									 {
										  for(u8 i=13;i>=2;i--)
										  {
											  LCD_VidWriteCommend(1);
											  constant2(5);
											constant(ball_down,48,1,i,6);
											_delay_ms(200);
									      }
									}
									}
					                else
					                {
					                 constant2(2);
									constant(ball_down,48,1,i,6);
									_delay_ms(200);
					                }



					              }
				 num2=0;
			}
			else if(num3==1)
					{
				for(u8 i=13;i>=1;i--)
			  {LCD_VidWriteCommend(1);
				  constant2(3);
				constant(ball_down,48,0,i,6);
				_delay_ms(200);
                if(i==1)
                {   GoToXY(0,4);
                	LCD_VidWriteString("GOOOAAAL");
                }
			  }
				num3=0;
					}
		   else if(num4==2)
		   {
				for(u8 i=13;i>=2;i--)
			  {
				LCD_VidWriteCommend(1);
				constant2(4);
				constant(ball_down,48,1,i,6);
				_delay_ms(200);

			  }
							num4=0;
		   }
		}


}
}


